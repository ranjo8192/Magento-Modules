<?php

namespace Signature\Deliverydate\Controller\Adminhtml\Holiday;

/**
 * Class Grid
 * @package Signature\Deliverydate\Controller\Adminhtml\Holiday
 */
class Grid extends \Signature\Deliverydate\Controller\Adminhtml\Holiday
{
    /**
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        return $this->_resultPageFactory->create();
    }
}
