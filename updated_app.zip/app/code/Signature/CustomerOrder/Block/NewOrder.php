<?php
namespace Signature\CustomerOrder\Block;
use Magento\Framework\View\Element\Template\Context;
use Magento\Catalog\Model\ProductRepository;
use Signature\CustomerOrder\Model\ConfigCollection;

class NewOrder extends \Magento\Framework\View\Element\Template
{ 
	 
	 /**
     * @var Magento\Catalog\Model\ProductRepository
     */
	 protected $_productRepository;
	 protected $_configCollection;
	 

	
	public function __construct(
		Context $context,
		ProductRepository $productRepository,
		ConfigCollection $configCollection,
		array $data = []
	) {
		$this->_productRepository = $productRepository;
		$this->_configCollection = $configCollection;
		parent::__construct($context, $data);
	}
	
	
	
	
	public function getProductById($id = null)
	{
		return $this->_productRepository->getById($id);
	}
	
	
	public function getCustomerSession(){
		
        return $this->_configCollection->getCustomerSession();
     }
	 
	public function getCustomerConfigCollection()
    {
        return $this->_configCollection->getCustomerConfigCollection();
    }
		
	public function getProductCollection()
	{
		return $this->_configCollection->getProductCollection();
	}
}