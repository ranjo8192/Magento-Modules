<?php
namespace Signature\CustomerOrder\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\ResultFactory;
use Psr\Log\LoggerInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Signature\CustomerOrder\Model\ConfigCollection;

class VerifyQuantity extends Action {
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    private $pageFactory;
	
	/**
     * @var Signature\CustomerOrder\Block\NewOrder
     */
    private $_congifCollection;
	
	/**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
	 
    private $resultJsonFactory;

	/**
     * @var \Magento\Framework\Controller\ResultFactory
     */
    private $resultRedirect;
	/**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;
    /**
     * NewOrder constructor.
     */
    public function __construct(
        Context $context,
        PageFactory $pageFactory,
		ResultFactory $result,
		LoggerInterface $logger,
		JsonFactory $JsonFactory,
		ConfigCollection $congifCollection
    )
    {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
		$this->request = $context->getRequest();
		$this->resultRedirect = $result;
		$this->logger = $logger;
		$this->resultJsonFactory = $JsonFactory;
		$this->_congifCollection = $congifCollection;
    }

    public function execute()
    {
		$post = $this->request->getPostValue();
		$customerConfigCollection = $this->_congifCollection->getCustomerConfigCollection();
		$_loadedCollection = $customerConfigCollection->getData();
		$allProductData = json_decode($_loadedCollection[0]['product_information'], true);
		$customer_product_config = $allProductData['product_qty'];
		$result = $this->resultJsonFactory->create();
	
		foreach($customer_product_config as $product_id => $customer_assign_qty )
		{
			 $id = (int)$post['pro_id'];
	
			if(!empty($customer_assign_qty)){
				
				if($product_id === $id ){
					
					$product_instock_qty = $this->_congifCollection->getQty($product_id);
					if(!empty($product_instock_qty) && !empty($customer_assign_qty) && $product_instock_qty >= $customer_assign_qty && $customer_assign_qty >= $post['quantity']){
	                
						$data = '';
					}else{

						$data = "Max quantity that can be order is {$customer_assign_qty}";
					}
				}
			}
		}
		$result->setData(["html"=>$data]);
		return $result;
    }
}
?>