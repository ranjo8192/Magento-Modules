<?php
namespace Magento\Customer\Model;
class Registration
{
    /**
     * Check whether customers registration is allowed
     * @return bool
     */
    public function isAllowed()
    {
        return false;
    }
}
?>