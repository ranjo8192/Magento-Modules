<?php
/**
 * Signature_Customer Salesrep Options Model.
 */
namespace Signature\Customer\Model\Config\Source;
use Magento\Customer\Model\CustomerFactory;
 
class SalesrepOptions extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
	protected $customerFactory;
	
	public function __construct(
		CustomerFactory $customerFactory
	) {
		$this->customerFactory = $customerFactory;
	}
	/**
     * Get Grid row language type labels array.
     * @return array
     */
    public function getOptionArray($group_id = '')
    {
		$customer_object = $this->customerFactory->create()->getCollection()
									   ->addAttributeToFilter('group_id', 5);                      
		$options = array();
        $options[0]	= "Select sales rep";	
		 foreach($customer_object as $customer){	 
			$options[$customer->getId()] = $customer->getName();
		} 
        return $options;
    }
 
    /**
     * Get Grid row language labels array with empty value for option element.
     *
     * @return array
     */
    public function getAllOptions()
    {
        $res = $this->getOptions();
        array_unshift($res, ['value' => '', 'label' => '']);
        return $res;
    }
 
    /**
     * Get Grid row type array for option element.
     * @return array
     */
    public function getOptions()
    {
        $res = [];
        foreach ($this->getOptionArray() as $index => $value) {
            $res[] = ['value' => $index, 'label' => $value];
        }
        return $res;
    }
 
    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        return $this->getOptions();
    }
}