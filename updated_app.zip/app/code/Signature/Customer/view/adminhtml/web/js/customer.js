require([
    'jquery'
], function ($) {
    'use strict';

setTimeout(function(){ 
		//"select[name=\'min_select[]\']"
		//alert($("select[name=\'customer[\'group_id\']\']").val()); 
       // $('.admin__field').attr('rep_name').hide();
  
}, 3000);
});