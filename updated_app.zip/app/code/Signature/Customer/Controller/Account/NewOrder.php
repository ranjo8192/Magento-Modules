<?php
namespace Signature\Customer\Controller\Account;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\View\Result\PageFactory;

class NewOrder extends Action {
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    private $pageFactory;


    /**
     * NewOrder constructor.
     * @param Context $context
     * @param PageFactory $pageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $pageFactory
    )
    {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
		$this->request = $context->getRequest();
    }

    public function execute()
    {
		$page = $this->pageFactory->create();
        return $page;
    }
	
}
?>