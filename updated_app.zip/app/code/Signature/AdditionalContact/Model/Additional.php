<?php
namespace Signature\AdditionalContact\Model;
use Magento\Framework\Model\AbstractModel;
class Additional extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('Signature\AdditionalContact\Model\ResourceModel\Additional');
    }
}