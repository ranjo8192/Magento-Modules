/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'jquery',
    'Magento_Ui/js/modal/confirm',
    'mage/translate'
], function ($, confirm) {
    'use strict';

    /**
     * @param {String} url
     * @returns {Object}
     */
    function getForm(url) {
        return $('<form>', {
            'action': url,
            'method': 'POST'
        }).append($('<input>', {
            'name': 'form_key',
            'value': window.FORM_KEY,
            'type': 'hidden'
        }));
    }

    $('#customer-edit-delete-button').click(function () {
        var msg = $.mage.__('Are you sure you want to do this?'),
            url = $('#customer-edit-delete-button').data('url');

        confirm({
            'content': msg,
            'actions': {

                /**
                 * 'Confirm' action handler.
                 */
                confirm: function () {
                    getForm(url).appendTo('body').submit();
                }
            }
        });

        return false;
    });
	
	$("[data-ui-id='save-button'],[data-ui-id='save-and-continue-button']").on("click.myEvent", function(e) {
		var $that = $(this);
		$that.off('click.myEvent');
		e.preventDefault();
		e.stopImmediatePropagation();
        var msg = $.mage.__('Are you sure you want to save this?');
	
        confirm({
            'content': msg,
            'actions': {
                confirm: function () {
					$that.trigger("click");
                }
            }
        });

        return false;
    });
});
