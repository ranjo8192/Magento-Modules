<?php
namespace Signature\Customers\Model\ResourceModel\Additional;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            'Signature\Customers\Model\Additional',
            'Signature\Customers\Model\ResourceModel\Additional'		
        );
    }
}