<?php
namespace Magepapa\Cataloglistview\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
 
/**
 * Webkul Hello Landing page Index Controller.
 */ 
class Index extends Action
{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Data\Form\FormKey $formKey,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->formKey = $formKey;
        $this->resultPageFactory = $resultPageFactory;
    }
 
    /**
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        
        $post = $this->getRequest()->getPost();
        $productID = $post['product'];
        $opt = substr(strrchr($post['option_value'], '-'), 1);
        //echo "Product Name..." .$productID;
       // echo "<pre>";
        //print_r($post);
       // die;
        //$_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        //$parentIds = $_objectManager->get('Magento\ConfigurableProduct\Model\Product\Type\Configurable')
                //->getParentIdsByChild($opt);
     //$parentId = array_shift($parentIds);
      //echo "Hey this is something strange" .$parentId;
      //die("this is die section");
      
     
        $resultPage = $this->resultPageFactory->create();
            $params = array(
                'form_key' => $this->formKey->getFormKey(),
                'product' =>$opt,//product Id
                'qty'   =>1,
                
            );
            $this->_redirect("checkout/cart/add/form_key/", $params);
        /** @var \Magento\Framework\View\Result\Page $resultPage */
        return $resultPage;
    }
}