<?php
namespace Magepapa\Hello\Block;
 
/*
 * Webkul Hello Block
 */
 
class Block extends \Magento\Framework\View\Element\Template
{
    /**
     * @return $this
     */
    protected function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
 
    /**
     * getContentForDisplay
     * @return string
     */
    public function getContentForDisplay()
    {
        return __("Successful! I was able to call a phtml file through block, He he!.");
    }
    
    public function getFormAction()
    {
        return $this->getUrl('cataloglistview/index/index', ['_secure' => true]);
    }
}