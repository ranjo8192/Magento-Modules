<?php
namespace Magepapa\Hello\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey;
 
/**
 * Webkul Hello Landing page Index Controller.
 */ 
class FormPost extends Action
{
	/**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $_formKey;

    public function __construct(
        Context $context,
		FormKey $formKey
	)
	{
        parent::__construct($context);
		$this->_formKey = $formKey;

	}
	
    public function execute()
    {
      $post = $this->getRequest->getPostValue();
	  echo "<pre>";
	  print_r($post);
	  die;
    }
}