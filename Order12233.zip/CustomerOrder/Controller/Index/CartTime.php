<?php
namespace Signature\CustomerOrder\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;

class CartTime extends Action {
	

	/**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    private $timezone;
	/**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
	 
    private $resultJsonFactory;
	/**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;
    /**
     * NewOrder constructor.
     * @param Context $context
	 * @param TimezoneInterface $timeZone
	 * @param JsonFactory $JsonFactory
     */
    public function __construct(
        Context $context,
		ScopeConfigInterface $scopeConfig,
		TimezoneInterface $timeZone,
		JsonFactory $JsonFactory
    )
    {
        parent::__construct($context);
		$this->request = $context->getRequest();
		$this->timezone = $timeZone;
		$this->resultJsonFactory = $JsonFactory;
		 $this->scopeConfig = $scopeConfig;
    }

    public function execute()
    {
		$result = $this->resultJsonFactory->create();
		$price_config = $this->scopeConfig->getValue('delivery_date/general/process_fee', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$start_time = $this->scopeConfig->getValue('delivery_date/general/start_time', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$end_time = $this->scopeConfig->getValue('delivery_date/general/end_time', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$closed_time = $this->scopeConfig->getValue('delivery_date/general/closed_day_time', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$post=$this->request->getPostValue(); 
		$message = '';
		$price = '';
		
		$date = $this->timezone->date()->format('Y-m-d');
		//$post['delivery_date']
		if(strtotime($date) == strtotime('2019-04-01')){

			$current_date_time = $this->timezone->date()->format('Y-m-d H:i');
			$currenttime = strtotime($current_date_time);
			if(strtotime($date .' '.$start_time)<$currenttime && strtotime($date .' '.$end_time)>$currenttime)
			{
				$message = 'A '. $price_config .' expedited processing fee will be added to your order.';
				$price = $price_config;
			}
			elseif(strtotime($date .' '.$closed_time)<$currenttime)
			{
				$message = 'Please call the office at 972-807-5916 to see if we can fill your order.';
			}
		}
		$result->setData(["html"=>$message,"price"=>$price]);
		return $result;
    }
	
}
?>