<?php
namespace Signature\CustomerOrder\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Checkout\Model\Cart;
use Magento\Catalog\Model\ProductFactory;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Controller\ResultFactory;
use Psr\Log\LoggerInterface;

class Index extends Action {
    /**
     * @var Magento\Catalog\Api\ProductRepositoryInterface
     */
    private $_productRepository;
	
	/**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @var \Magento\Checkout\Model\Cart
     */
    private $cart;
	/**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    private $product;
	/**
     * @var \Magento\Framework\Controller\ResultFactory
     */
    private $resultRedirect;
	/**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;
    /**
     * NewOrder constructor.
     * @param Context $context
     * @param PageFactory $pageFactory
	 * @param PageFactory $cart
	 * @param PageFactory $product
	 * @param PageFactory $result
	 * @param PageFactory $logger
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
		Cart $cart, 
		ProductFactory $product,
		ResultFactory $result,
		LoggerInterface $logger,
		ProductRepositoryInterface $productRepository
    )
    {
        parent::__construct($context);
        $this->_resultPageFactory = $resultPageFactory;
		$this->request = $context->getRequest();
		$this->cart = $cart;
		$this->product = $product;
		$this->resultRedirect = $result;
		$this->logger = $logger;
		$this->_productRepository = $productRepository;
    }

    public function execute()
    {
		$post = $this->request->getPostValue();
		$paramss = array();
		if(!empty($post['product_check']))
		{	
			for($i=0;$i<count($post['product_check']);$i++)
			{
				$paramss[]=array('form_key'=>$post['form_key'],'product'=>$post['product_check'][$i],'qty'=>(int)$post['qty'][$post['product_check'][$i]],'price'=>$post['productprice'][$post['product_check'][$i]]);
			}
		}
		
		$resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
		try{
			if(!empty($paramss)){
				foreach ($paramss as $params) {
			    
					$resultPage = $this->_resultPageFactory->create();
					$_productId = $productData['product'];
					$_product = $this->_productRepository->getById($productData['product']);
					
					$formkey = $productData['form_key'];
					$price = $productData['price'];
					$qty = $productData['qty'];
					$params = array(
					  'form_key' => $formkey,
					  'product' => $_productId,
					  'qty'   => $qty,
					  'price' => $price
					);
					
				$this->cart->addProduct($_product, $params);
			
				}
					$this->cart->save();
				}
			$resultRedirect->setUrl('checkout/cart/');  
		}catch(Exception $e) {
		  $this->logger->info($e->getMessage());
		  $resultRedirect->setUrl('customer-order/');
		}
		return $resultRedirect; 
    }
	
}
https://webkul.com/blog/add-product-cart-magento2/
<?php
$productIdArray = [1,2,3];
$cart = $this->_cartModel;
$storeId = $this->storeManager->getStore()->getId();
foreach ($productIdArray as $key => $productId) 
{ 
$params = [
 ‘form_key’ => $this->formKey->getFormKey(), 
 ‘product’ => $productId,//product Id 
 ‘qty’ =>1,//quantity of product 
 ‘price’ =>100, //product price ]; 
 try { 
 $request = new MagentoFrameworkDataObject(); 
 $request->setData($params); 
 $productAddToCart = $this->productRepository->getById($productId, false, $storeId, true); 
 $cart->addProduct($productAddToCart, $request); 
 $this->messageManager->addSuccess(__(‘%1 is added in your cart’,$productAddToCart->getName())); 
 } 
 catch (Exception $e) 
 { 
 $this->messageManager->addError(__($e->getMessage())); 
 }
 }
 $cart->save();
?>
?>
