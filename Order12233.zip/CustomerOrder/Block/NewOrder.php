<?php
namespace Signature\CustomerOrder\Block;
use Magento\Framework\View\Element\Template\Context;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\ObjectManagerInterface;
use Signature\Customers\Model\AdditionalFactory;
use Magento\Catalog\Model\ProductRepository;

class NewOrder extends \Magento\Framework\View\Element\Template
{ 
   /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
	protected $_productCollectionFactory;
	
	/**
	 * @var \Magento\Framework\ObjectManagerInterface
	 */
	protected $_object;
	
	/**
     * @var Signature\Customers\Model\Additional
     */
	 protected $_additional;
	 
	 /**
     * @var Magento\Catalog\Model\ProductRepository
     */
	 protected $_productRepository;

	
	public function __construct(
		Context $context,
		CollectionFactory $productCollectionFactory,
		ObjectManagerInterface $interface,
		AdditionalFactory $additional,
		ProductRepository $productRepository,
		array $data = []
	) {
		$this->_productCollectionFactory = $productCollectionFactory; 
        $this->_object = $interface;
		$this->_additional = $additional;
		$this->_productRepository = $productRepository;
		parent::__construct($context, $data);
	}
	
	
	
	
	public function getProductById($id = null)
	{
		return $this->_productRepository->getById($id);
	}
	
	
	public function getCustomerSession(){
        $customerSession = $this->_object->create('Magento\Customer\Model\Session');
		if($customerSession->isLoggedIn()){
		    return $customerSession->getCustomerData();
		}    
     }
	 
	public function getCustomerConfigCollection()
    {
		$customerData = $this->getCustomerSession();
		$customerId = $customerData->getId();
		$configCollection = $this->_additional->create()->getCollection()
														->addFieldToSelect('*')
														->addFieldToFilter('customer_id',$customerId);
        return $configCollection;
    }
		
	public function getProductCollection()
	{
		$_configCollection = $this->getCustomerConfigCollection();
		$data = $_configCollection->getData();
		$allProductData = json_decode($data[0]['product_information'], true);
		$collection = $this->_productCollectionFactory->create();
		$collection->addAttributeToSelect('*')
				   ->addAttributeToFilter('entity_id', array('in' => $allProductData['product_id']))
				   ->load();
		return $collection;
	}
}