<?php

/**
 * Signature\SalesRep\Block\Account\Doctors
 */
namespace Signature\SalesRep\Block\Account;

class Doctors extends \Magento\Framework\View\Element\Template {

    
    /**
     * Create constructor.
     * @param Magento\Framework\View\Element\Template\Context $context
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context
    ) {
        parent::__construct($context);
    }

    /**
     * Returns action url for contact form
     *
     * @return string
     */
    public function getNewOrderAction() {
        return $this->getUrl('customer/account/neworder', ['_secure' => true]);
    }
    
    /**
     * Returns action url for contact form
     *
     * @return string
     */
    public function getDeleteAction() {
        return $this->getUrl('salesrep/account/delete', ['_secure' => true]);
    }

}
