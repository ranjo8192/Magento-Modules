<?php

/**
 * Signature\SalesRep\Block\Account\AddDoctor
 */

namespace Signature\SalesRep\Block\Account;

class AddDoctor extends \Magento\Framework\View\Element\Template {

    protected $directoryBlock;
    protected $_countryCollectionFactory;
    protected $_regionColFactory;

    public function __construct(
    \Magento\Framework\View\Element\Template\Context $context, \Magento\Directory\Block\Data $directoryBlock, \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory, \Magento\Directory\Model\RegionFactory $regionColFactory, array $data = []
    ) {
        parent::__construct($context, $data);
        $this->directoryBlock = $directoryBlock;
        $this->_countryCollectionFactory = $countryCollectionFactory;
        $this->_regionColFactory = $regionColFactory;
    }

    public function _prepareLayout() {
        return parent::_prepareLayout();
    }
    
    public function getFormAction() {
        return $this->getUrl('salesrep/account/register', ['_secure' => true]);
    }

    public function getRegion() {
        $state_list = $this->_regionColFactory->create()->getCollection()->addFieldToFilter('country_id', 'US');
        $final_state_list = $state_list->toOptionArray();
        return $final_state_list;
    }

    public function getCountryCollection() {
        $collection = $this->_countryCollectionFactory->create();
        return $collection;
    }

    /**
     * Retrieve list of countries in array option
     *
     * @return array
     */
    public function getCountries() {
        $options = $this->getCountryCollection()->toOptionArray();
        return $options;
    }

}
