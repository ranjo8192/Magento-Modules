<?php

namespace Signature\SalesRep\Controller\Account;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\UrlInterface;

class PlaceOrder extends Action {

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    private $pageFactory;

    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_object;

    /**
     * @var \Magento\Framework\Controller\ResultFactory
     */
    private $resultRedirect;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    private $url;

    /**
     * NewOrder constructor.
     * @param Context $context
     * @param PageFactory $pageFactory
     * @param ObjectManagerInterface $interface
     * @param ResultFactory $result
     * @param UrlInterface $url
     */
    public function __construct(
    Context $context, PageFactory $pageFactory, ObjectManagerInterface $interface, ResultFactory $result, UrlInterface $url
    ) {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
        $this->request = $context->getRequest();
        $this->_object = $interface;
        $this->resultRedirect = $result;
        $this->url = $url;
    }

    /**
     * @var checking for customer login functionality
     *
     * @return $page or resultRedirect
     */
    public function execute() {
        $customerSession = $this->_object->create('Magento\Customer\Model\Session');
        if ($customerSession->isLoggedIn()) {
            $page = $this->pageFactory->create();
            return $page;
        } else {
            $resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($this->url->getUrl('customer/account/login'));
            return $resultRedirect;
        }
    }

}

?>