<?php

namespace Signature\SalesRep\Controller\Account;

use Magento\Framework\App\RequestFactory;
use Magento\Customer\Model\CustomerExtractor;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Exception\InputException;

class Delete extends \Magento\Framework\App\Action\Action {

    /**
     * Escaper
     *
     * @var \Magento\Framework\Escaper
     */
    protected $_escaper;

    /**
     * @var customer
     */
    protected $customer;

    /**
     * @var customerFactory
     */
    protected $customerFactory;

    /**
     * @var RequestFactory
     */
    protected $requestFactory;

    /**
     * @var CustomerExtractor
     */
    protected $customerExtractor;

    /**
     * @var AccountManagementInterface
     */
    protected $customerAccountManagement;

    /**
     * @var _customerSession
     */
    protected $_customerSession;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param RequestFactory $requestFactory
     * @param CustomerExtractor $customerExtractor
     * @param AccountManagementInterface $customerAccountManagement
     * @param \Magento\Customer\Model\Customer $customer
     * @param \Magento\Customer\Model\ResourceModel\CustomerFactory $customerFactory
     */
    public function __construct(
    \Magento\Framework\App\Action\Context $context, RequestFactory $requestFactory, \Magento\Framework\Escaper $_escaper, CustomerExtractor $customerExtractor, \Magento\Customer\Model\SessionFactory $customerSession, AccountManagementInterface $customerAccountManagement, \Magento\Customer\Model\Customer $customer, \Magento\Framework\App\Cache\Manager $cacheManager, \Magento\Customer\Model\ResourceModel\CustomerFactory $customerFactory
    ) {
        $this->requestFactory = $requestFactory;
        $this->customerExtractor = $customerExtractor;
        $this->customerAccountManagement = $customerAccountManagement;
        $this->_customerSession = $customerSession->create();
        $this->customer = $customer;
        $this->_escaper = $_escaper;
        $this->customerFactory = $customerFactory;
        parent::__construct($context);
    }

    /**
     * Retrieve sources
     * 
     * @return array
     */
    public function execute() {
        $resultRedirect = $this->resultRedirectFactory->create();
        $post = $this->getRequest()->getPostValue();
        echo "Line 79 ===> <pre>";
        print_r($post);
        die();

        if (!$this->getRequest()->isPost()) {
            $url = $this->urlModel->getUrl('salesrep/account/adddoctor', ['_secure' => true]);
            $resultRedirect->setUrl($this->_redirect->error($url));
            return $resultRedirect;
        }
        // $password 	= $post['password'];
        // $confirmation 	= $post['password_confirmation'];
        $password = 'Hello@123';
        $confirmation = 'Hello@123';
        //$this->checkPasswordConfirmation($password, $confirmation);			
        $customerData = [
            'firstname' => $post['firstname'],
            'lastname' => $post['lastname'],
            'email' => $post['email'],
        ];

        $request = $this->requestFactory->create();
        $request->setParams($customerData);
        try {
            $customer = $this->customerExtractor->extract('customer_account_create', $request);
            $customer = $this->customerAccountManagement->createAccount($customer, $password);
            $this->saveCustomerAttribute($customer, $post);
            $this->saveShippingAddress($customer, $post);
            
            if (!isset($post['sameShipping'])) {
                $this->saveBillingAddress($customer, $post);
            }

            $this->messageManager->addSuccess(__('Thank you for requesting an account.'));
            $resultRedirect->setPath('salesrep/account/doctors');
            return $resultRedirect;
        } catch (StateException $e) {
            $this->messageManager->addError(__('There is already an account with this email address.'));
        } catch (InputException $e) {
            $this->messageManager->addError($this->_escaper->escapeHtml($e->getMessage()));
            foreach ($e->getErrors() as $error) {
                $this->messageManager->addError($this->_escaper->escapeHtml($error->getMessage()));
            }
        } catch (LocalizedException $e) {
            $this->messageManager->addError($this->_escaper->escapeHtml($e->getMessage()));
        } catch (\Exception $e) {
            $this->messageManager->addException($e, __('We can\'t save the customer.'));
        }
        $resultRedirect->setPath('salesrep/account/adddoctor');
        return $resultRedirect;
    }

    /**
     * Save Billing Address
     *
     * @return bool
     */
    public function saveBillingAddress($customer, $post) {
        $addresss = $this->_objectManager->get('\Magento\Customer\Model\AddressFactory');
        $billing_address = $addresss->create();

        $billing_address->setCustomerId($customer->getId())
                ->setFirstname($customer->getFirstname())
                ->setLastname($customer->getLastname())
                ->setCountryId($post['bcountry_id'])
                ->setRegionId($post['bregion_id'])
                ->setPostcode($post['bpostcode'])
                ->setCity($post['bcity'])
                ->setTelephone($post['telephone'])
                ->setStreet($post['bstreet'])
                ->setIsDefaultShipping(false)
                ->setIsDefaultBilling(1)
                ->setSaveInAddressBook(1);
        $billing_address->save();
    }

    /**
     * Save Shipping Address
     * @param 
     * @return bool
     */
    public function saveShippingAddress($customer, $post) {
        $addresss = $this->_objectManager->get('\Magento\Customer\Model\AddressFactory');
        $shipping_address = $addresss->create();
        $IsDefaultBilling = isset($post['sameShipping']) ? $post['sameShipping'] : false;
        
        $shipping_address->setCustomerId($customer->getId())
                ->setFirstname($customer->getFirstname())
                ->setLastname($customer->getLastname())
                ->setCountryId($post['scountry_id'])
                ->setRegionId($post['sregion_id'])
                ->setPostcode($post['spostcode'])
                ->setCity($post['scity'])
                ->setTelephone($post['telephone'])
                ->setStreet($post['sstreet'])
                ->setIsDefaultBilling($IsDefaultBilling)
                ->setIsDefaultShipping(1)
                ->setSaveInAddressBook(1);
        $shipping_address->save();
    }

    /**
     * Save Customer Custom Attribute
     * @param customer
     * @return bool
     */
    public function saveCustomerAttribute($customer, $post) {
        $customerRepository = $this->_objectManager->get('Magento\Customer\Api\CustomerRepositoryInterface');
        $customerCustomAttribute = $customerRepository->getById($customer->getId());
        $customerCustomAttribute->setCustomAttribute('doctor_npi', $post['doctor_npi']);
        $customerCustomAttribute->setCustomAttribute('npi_status', $post['npi_status']);
        $customerCustomAttribute->setCustomAttribute('other_info_desc', $post['other_info_desc']);
        $customerCustomAttribute->setCustomAttribute('rep_name', $this->getLoggedinCustomerId());
        $customerRepository->save($customerCustomAttribute);
    }

    /**
     * Get Customer Loggedin ID
     * @param customer
     * @return bool
     */
    public function getLoggedinCustomerId() {
        if ($this->_customerSession->isLoggedIn()) {
            return $this->_customerSession->getId();
        }
        return false;
    }

}
