require([
    "jquery",
	'mage/url'
], function ($, url) {
    'use strict';
	
	$(".trigger_popup_fricc").click(function(){
	$('.hover_bkgr_fricc').show();
	});
	$('.popupCloseButton').click(function(){
	$('.hover_bkgr_fricc').hide();
	});
	
	$(".tab_content").hide();
    $(".tab_content:first").show();
    $("ul.tabs li").click(function() {
		// NPI# validate
		if($('#npi_status').val()==0){
			return false;
		}
      $(".tab_content").hide();
      var activeTab = $(this).attr("rel"); 
      $("#"+activeTab).fadeIn();		
		
      $("ul.tabs li").removeClass("active");
      $(this).addClass("active");

	  $(".tab_drawer_heading").removeClass("d_active");
	  $(".tab_drawer_heading[rel^='"+activeTab+"']").addClass("d_active");
	  
    });
    $(".tab_container").css("min-height", function(){ 
      return $(".tabs").outerHeight() + 50;
    });

	$(".tab_drawer_heading").click(function() {
      
      $(".tab_content").hide();
      var d_activeTab = $(this).attr("rel"); 
      $("#"+d_activeTab).fadeIn();
	  
	  $(".tab_drawer_heading").removeClass("d_active");
      $(this).addClass("d_active");
	  
	  $("ul.tabs li").removeClass("active");
	  $("ul.tabs li[rel^='"+d_activeTab+"']").addClass("active");
    });
	
	function validateEmail(email) {
	var re = /^\w+([-+.'][^\s]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
	var emailFormat = re.test(email);
	if (emailFormat) {
	   return true;
	}else{
	  return false;
	}
}
    $(document).ready(function(){
        $('.checkSameAddress').click(function(){
            if($(this).prop("checked") == true){
				
				$('#BillingAddressDiv').hide();
				$('.checkSameAddress').val(1);
            }
            else if($(this).prop("checked") == false){
				$('.checkSameAddress').val(0);
               $('#BillingAddressDiv').show(); 
            }
        });
	  $('.continueTabBtn').click(function(e){
		e.preventDefault();
		var backTab=parseInt($(this).attr('tab_data'))+1;
		if(backTab=='2'){
			if($.trim($('#firstname').val())!='' && $.trim($('#lastname').val())!='' && $.trim($('#email_address').val())!='' && validateEmail($.trim($('#email_address').val())) && $.trim($('#password').val())!='' && $.trim($('#password-confirmation').val())!='' && ($('#profile_group').val()!=4 || ($.trim($('#doctor_npi').val())!='' && $('#profile_group').val()==4)))
			{ 
		        $('#tb'+backTab).trigger('click'); 
			}else{
				if($.trim($('#firstname').val())=='')
				{
					$('#firstname').addClass('mage-error');
					if($('#firstname-error').length==0){
					$("input#firstname").after('<div for="password" generated="true" class="mage-error" id="firstname-error">This is a required field.</div>');
					}
				}else{
					$('#firstname').removeClass('mage-error');
					$("#firstname-error").remove();
				}
				if($.trim($('#lastname').val())=='')
				{
					$('#lastname').addClass('mage-error');
					if($('#lastname-error').length==0){
					$("input#lastname").after('<div for="lastname" generated="true" class="mage-error" id="lastname-error">This is a required field.</div>');
					}
				}
				else{
					$('#lastname').removeClass('mage-error');
					$("#lastname-error").remove();
				}
				if($.trim($('#email_address').val())=='')
				{
					$('#email_address').addClass('mage-error');
					if($('#email_address-error').length==0){
					$("input#email_address").after('<div for="email_address" generated="true" class="mage-error" id="email_address-error">This is a required field.</div>');
					}
				}
				else{
					if(!validateEmail($.trim($('#email_address').val())))
					{
						$('#email_address-error').html('Please enter a valid email address (Ex: johndoe@domain.com).');
					}
					else{
						$('#email_address').removeClass('mage-error');
						$("#email_address-error").remove();
					}
				}
				if($.trim($('#password').val())=='')
				{
					$('#password').addClass('mage-error');
					if($('#password-error').length==0){
					$("input#password").after('<div for="password" generated="true" class="mage-error" id="password-error">This is a required field.</div>');
					}
				}
				else{
					$('#password').removeClass('mage-error');
					$("#password-error").remove();
				}
				if($.trim($('#password-confirmation').val())=='')
				{
					$('#password-confirmation').addClass('mage-error');
					if($('#password-confirmation-error').length==0){
					$("input#password-confirmation").after('<div for="password-confirmation" generated="true" class="mage-error" id="password-confirmation-error">This is a required field.</div>');
					}
				}
				else{
					$('#password-confirmation').removeClass('mage-error');
					$("#password-confirmation-error").remove();
				}
				if($.trim($('#doctor_npi').val())=='' && $('#profile_group').val()==4)
				{
					$('#doctor_npi').addClass('mage-error');
					if($('#doctor_npi-error').length==0){
					$("input#doctor_npi").after('<div for="doctor_npi" generated="true" class="mage-error" id="doctor_npi-error">This is a required field.</div>');
					}
				}
				else{
					$('#doctor_npi').removeClass('mage-error');
					$("#doctor_npi-error").remove();
				}
			}
		}
        if(backTab=='3'){
			if($.trim($('#street_1').val())!='' && $.trim($('#city').val())!='' && $.trim($('#region_id').val())!=0 && $.trim($('#zip').val())!='' && $.trim($('#country').val())!='')
			{ 
		         if($('#profile_group').val()==5){ backTab=4; }
		        $('#tb'+backTab).trigger('click'); 
			}else{
				if($.trim($('#street_1').val())=='')
				{
					$('#street_1').addClass('mage-error');
					if($('#street_1-error').length==0){
					$("input#street_1").after('<div for="street_1" generated="true" class="mage-error" id="street_1-error">This is a required field.</div>');
					}
				}
				else{
					$('#street_1').removeClass('mage-error');
					$("#street_1-error").remove();
				}
				if($.trim($('#city').val())=='')
				{
					$('#city').addClass('mage-error');
					if($('#city-error').length==0){
					$("input#city").after('<div for="city" generated="true" class="mage-error" id="city-error">This is a required field.</div>');
					}
				}
				else{
					$('#city').removeClass('mage-error');
					$("#city-error").remove();
				}
				if($.trim($('#region_id').val())==0)
				{
					$('#region_id').addClass('mage-error');
					if($('#region_id-error').length==0){
					$("select#region_id").after('<div for="region_id" generated="true" class="mage-error" id="region_id-error">This is a required field.</div>');
					}
				}
				else{
					$('#region_id').removeClass('mage-error');
					$("#region_id-error").remove();
				}
				if($.trim($('#zip').val())=='')
				{
					$('#zip').addClass('mage-error');
					if($('#zip-error').length==0){
					$("input#zip").after('<div for="zip" generated="true" class="mage-error" id="zip-error">This is a required field.</div>');
					}
				}
				else{
					$('#zip').removeClass('mage-error');
					$("#zip-error").remove();
				}
				
				if($.trim($('#country').val())=='')
				{
					$('#country').addClass('mage-error');
					if($('#country-error').length==0){
					$("select#country").after('<div for="country" generated="true" class="mage-error" id="country-error">This is a required field.</div>');
					}
				}
				else{
					$('#country').removeClass('mage-error');
					$("#country-error").remove();
				}
			}
		}	
		if(backTab=='4' && $('#profile_group').val()!=5){
			if($('.checkSameAddress').prop("checked")==false){
				if($('#bstreet_1').val()!='' && $('#bcity').val()!='' && $('#bregion_id').val()!=0 && $('#bzip').val()!='' && $('#bcountry').val()!='')
				{
					$('#tb'+backTab).trigger('click');
					
				}else{
					if($.trim($('#bstreet_1').val())=='')
					{
						$('#bstreet_1').addClass('mage-error');
						if($('#bstreet_1-error').length==0){
						$("input#bstreet_1").after('<div for="bstreet_1" generated="true" class="mage-error" id="bstreet_1-error">This is a required field.</div>');
						}
					}
					else{
					$('#bstreet_1').removeClass('mage-error');
					$("#bstreet_1-error").remove();
				    }
					if($.trim($('#bcity').val())=='')
					{
						$('#bcity').addClass('mage-error');
						if($('#bcity-error').length==0){
						$("input#bcity").after('<div for="bcity" generated="true" class="mage-error" id="bcity-error">This is a required field.</div>');
						}
					}
					else{
					$('#bcity').removeClass('mage-error');
					$("#bcity-error").remove();
				    }
					if($.trim($('#bregion_id').val())==0)
					{
						$('#bregion_id').addClass('mage-error');
						if($('#bregion_id-error').length==0){
						$("select#bregion_id").after('<div for="bregion_id" generated="true" class="mage-error" id="bregion_id-error">This is a required field.</div>');
						}
					}
					else{
					$('#bregion_id').removeClass('mage-error');
					$("#bregion_id-error").remove();
				    }
					if($.trim($('#bzip').val())=='')
					{
						$('#bzip').addClass('mage-error');
						if($('#bzip-error').length==0){
						$("input#bzip").after('<div for="bzip" generated="true" class="mage-error" id="bzip-error">This is a required field.</div>');
						}
					}
					else{
					$('#bzip').removeClass('mage-error');
					$("#bzip-error").remove();
				    }
					if($.trim($('#bcountry').val())=='')
					{
						$('#bcountry').addClass('mage-error');
						if($('#bcountry-error').length==0){
						$("select#bcountry").after('<div for="bcountry" generated="true" class="mage-error" id="bcountry-error">This is a required field.</div>');
						}
					}
					else{
					$('#bcountry').removeClass('mage-error');
					$("#bcountry-error").remove();
				    }
				}	
			}else{
				$('#tb'+backTab).trigger('click');
			}
		}
		    

					
		
       });

		$('.backTabBtn').click(function(e){
		e.preventDefault();
		var backTab=parseInt($(this).attr('tab_data'))-1;
		$('#tb'+backTab).trigger('click');
		});
    });
	    // NPI# Validation after Onblur
		$(document).on('click','.npivaidate',function(e){
			e.preventDefault();
			$.ajax({
				url:url.build('verify_npi/'),
				type:'POST',
				dataType:'json',
				data:{npi_number:$('#doctor_npi').val()},
				success: function(response) {
					if(response.Status=='Active')
					{
						$('#npi_status').val(1);
						$('#npi-valid-msg').html('<span style="color:green;font-size: 1.2rem;">NPI number is valid you can proceed to continue.</span>');
						$('.validateButton .npivaidate').hide();
						$('.validateButton .fa-check-circle').show();
					}
					if(response.Status=='NotFound')
					{
						$('#npi_status').val(0);
						$('#npi-valid-msg').html('<span style="color:red;font-size: 1.2rem;">NPI number is invalid.Please enter npi valid number to proceed continue.</span>');
					}
				},
				error: function(response) {
                console.log(response);
				}
			});
		});
		
		// Go to registration  after select and click submit
		$(document).on('click','#createProfile',function()
		{
			window.location.href = url.build('customer/account/create/profile/' + $('#profile_id').val());
		});
		
		// Create new order jQuery code here
		
		// Multiple select products after checked
		$("#select_all").change(function(){  
			$(".checkbox").prop('checked', $(this).prop("checked")); 
			$('.tocart').attr('disabled',false);
		});
		
		// Single select product after checked
		$('.checkbox').change(function(){ 
			if(false == $(this).prop("checked")){ 
				$("#select_all").prop('checked', false); 
				$('.tocart').attr('disabled',true);
			}else
			{
			    $('.tocart').attr('disabled',false);
			}	
			if ($('.checkbox:checked').length == $('.checkbox').length ){
			    $("#select_all").prop('checked', true);
			}
		});
		
		// Add to cart after click button
		$(document).on('click','.tocart',function(e)
		{
			e.preventDefault();
			$('#customerCheckoutForm').show();
			$(this).attr('disabled',true);
		});
		$(document).on('click','#cancelBtn',function(e)
		{
			e.preventDefault();
			$('#customerCheckoutForm').hide();
			$('.tocart').attr('disabled',false);
		});	
		 /* $(document).on('click','.checkout-index-index .actions-toolbar .checkout',function(e){
			e.preventDefault();
			$.ajax({
				url:url.build('cart-time/index/carttime/'),
				type:'POST',
				dataType:'json',
				data:{},
				success: function(response) {
					if(response.html!="")
					{
						$('.hover_bkgr_fricc_price').show();
						$('#priceMessage').html(response.html);
			            if(response.price=='')
						{
							$('#acceptPrice').hide();
						}
					}
					
				},
				error: function(response) {
				console.log(response);
				}
			});
			return false;
		});  */
		/* $(document).on('click','.tocart',function(e){
			e.preventDefault();
			$.ajax({
				url:url.build('cart-time/index/carttime/'),
				type:'POST',
				dataType:'json',
				data:{},
				success: function(response) {
					if(response.html!="")
					{
						$('.hover_bkgr_fricc_price').show();
			            $(this).attr('disabled',true);
						$('#priceMessage').html(response.html);
						$('#processing_fee').val(response.price);
					}
					
				},
				error: function(response) {
				console.log(response);
				}
			});
		}); */
		
		// sessionStorage.setItem("is_displayed", false);
		// localStorage.setItem('is_displayed', 0);
		// Accept exceed price after click button
		 $(document).on('click','#acceptPrice',function(e){
			e.preventDefault();
			$('.hover_bkgr_fricc_price').hide();
			$('#checkout-step-shipping_method #shipping-method-buttons-container .continue').trigger('click');

		});	
	
		// Not accept exceed price after click button
		$(document).on('click','.popupInfoCloseButton',function(e){
			e.preventDefault();
			$('.hover_bkgr_fricc_price').hide();
			$('#delivery_date_select').remove();
		});	 
		
		// Not proceed to cart after click button
		/* $(document).on('click','#cancelBtn',function(e)
		{
			e.preventDefault();
			$('#customerCheckoutForm').hide();
			$('.tocart').attr('disabled',false);
		});	 */
		
		//$(document).on('click','#checkout-step-shipping_method #shipping-method-buttons-container .continue',function(e){
		//	
		//	if($('#delivery_date_select').val() === undefined)
		//	{
		//	 $("input[name='delivery-date']").val('');
		//
		//	 $("input[name='delivery-date']").after('<div id="delivery_date_error" generated="true" class="mage-error" >Please select delivery date.</div>');
		//	 e.preventDefault();
		//	}
		//}); 
		//$(document).on('change',"input[name='delivery-date']",function(e){
		//	e.preventDefault();
		//	$.ajax({
		//		url:url.build('cart-time/index/carttime/'),
		//		type:'POST',
		//		dataType:'json',
		//		data:{'delivery_date':$(this).val()},
		//		success: function(response) {
		//			if(response.html!="")
		//			{
		//				$('.hover_bkgr_fricc_price').show();
		//				$('#priceMessage').html(response.html);
		//	            if(response.price==''){
		//					$('#acceptPrice').hide();
		//				}
		//				if(response.price!=''){
		//					$('#acceptPrice').show();
		//				}
		//				$('#delivery_date_error').remove();
		//			}
		//		},
		//		error: function(response) {
		//		console.log(response);
		//		}
		//	});
		//	$('#onepage-checkout-shipping-method-additional-load').append('<input type="hidden" value="delivery_date_select" id="delivery_date_select">');
        //
		//});
});