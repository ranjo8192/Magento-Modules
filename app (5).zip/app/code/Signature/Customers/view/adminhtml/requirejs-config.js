var config = {
    map: {
        '*': {
            popuprequirejs: 'Signature_Customers/js/post_wrapper'
        }
    }
};
