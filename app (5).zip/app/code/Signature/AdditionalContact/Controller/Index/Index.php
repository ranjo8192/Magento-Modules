<?php
 
namespace Signature\AdditionalContact\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Signature\AdditionalContact\Model\AdditionalFactory;
class Index extends \Magento\Framework\App\Action\Action
{
	protected $_customerSession;
	
	protected $_additional;
	
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Customer\Model\Session $customerSession,
		AdditionalFactory $additional
    )	{
		
       parent::__construct($context);
	   $this->_customerSession = $customerSession;
	   $this->_additional = $additional;
    }
     
    public function execute()
    {
		
		$post = $this->getRequest()->getPostValue();

        if (!$post) {
			$this->_redirect('customer/account/edit/');
			return;
		}
		try {

			$customerID =  $this->_customerSession->getCustomer()->getId();
			
			$collection = $this->_additional->create()->getCollection()
													  ->addFieldToSelect(['customer_id','additional_id'])
												      ->addFieldToFilter('customer_id',$customerID);
			
			$firstName = $post['contact_firstname'];
			$lastName = $post['contact_lastname'];
			$email = $post['contact_email'];
			$trackingInformation = $post['contact_tracking'];
			$model = $this->_additional->create();
			if(count($collection) > 0){
				//die("hello");
				$data =  $collection->getFirstItem();
				$id  = $data->getAdditionalId();
				//die($id);
				$model->load($id);
			}
			$model->setCustomerId($customerID);
			$model->setFirstName($firstName);
			$model->setLastName($lastName);	
			$model->setEmail($email);
			$model->setTrackingInformation($trackingInformation);

			 
				$model->save();	
			
			
			$this->messageManager->addSuccess(__('Your Additonal contact has been saved successfully.'));
			$this->_redirect('customer/account/edit/');
			return;
			} catch (\Exception $e) {
			$this->messageManager->addError(__('We can\’t process your request right now. Sorry, check your details and try again.'));
			$this->_redirect('customer/account/edit/');
			return;
			}
			}
} 