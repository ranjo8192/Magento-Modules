<?php
/**
 * Signature\CustomerOrder\Observer
 *
 */
namespace Signature\CustomerOrder\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Checkout\Model\Cart;

class CustomPrice implements ObserverInterface
    {	
		
		protected $_request;
		
		protected $_cart;
		
	
		public function __construct(
			RequestInterface $request,
			Cart $cart

		) { 
			$this->_request = $request;
			$this->_cart = $cart;
		}
		
        public function execute(\Magento\Framework\Event\Observer $observer) {
			
			$post = $this->_request->getPost();
			try{
				if(!empty($post['product_check']))
				{	
					for($i=0;$i<count($post['product_check']);$i++)
					{
						$items = $this->_cart->getQuote()->getAllItems();
						foreach($items as $item) {
							$item->setCustomPrice($post['productprice'][$item->getProductId()]);
							$item->setOriginalCustomPrice($post['productprice'][$item->getProductId()]);
							$item->getProduct()->setIsSuperMode(true);									
						  }
					}
				}
			}catch(Exception $e) {
				$logger->info($e->getMessage());
					
				}
		}
}
