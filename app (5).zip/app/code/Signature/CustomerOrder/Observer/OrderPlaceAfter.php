<?php
namespace Signature\CustomerOrder\Observer;

use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Sales\Api\OrderRepositoryInterface;


class OrderPlaceAfter implements ObserverInterface
{
		protected $_loggers;
		
		protected $orderRepository;
		/**
		 * Order Model
		 *
		 * @var \Magento\Sales\Model\Order $order
		 */
		protected $_order;
		
		public function __construct
		(
		LoggerInterface $loggers,
		OrderRepositoryInterface $OrderRepositoryInterface,
		\Magento\Sales\Model\Order $order
		)
		{
		$this->_loggers = $loggers;
		$this->orderRepository = $OrderRepositoryInterface;
		$this->_order = $order;
		}
		
		public function execute(\Magento\Framework\Event\Observer $observer)
			{
			   $orderId = $observer->getEvent()->getOrderIds();
				$order = $this->_order->load($orderId);
				$customer = $order->getCustomerId(); // using this id you can get customer name

				//get Order All Item
				$itemCollection = $order->getItemsCollection();
				$orderData = $itemCollection->getData();
				//$_productId  = $orderData['info_buyRequest']['product'];
				$orderedQty  = $orderData[0]['qty_ordered'];
				//$_productPrice  = $orderData['info_buyRequest']['product'];
				
				
				$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
				$logger = new \Zend\Log\Logger();
				$logger->addWriter($writer);
				//$logger->info();
				$logger->info($orderedQty);
			}
}