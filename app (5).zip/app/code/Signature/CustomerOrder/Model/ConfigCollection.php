<?php
namespace Signature\CustomerOrder\Model;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\ObjectManagerInterface;
use Signature\Customers\Model\AdditionalFactory;
use Magento\Catalog\Model\ProductRepository;
use Magento\CatalogInventory\Model\Stock\StockItemRepository;

class ConfigCollection
{
	/**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
	protected $_productCollectionFactory;
	
	/**
	 * @var \Magento\Framework\ObjectManagerInterface
	 */
	protected $_object;
	
	/**
     * @var Signature\Customers\Model\Additional
     */
	 protected $_additional;
	 
	 /**
     * @var Magento\Catalog\Model\ProductRepository
     */
	 protected $_productRepository;
	 
	/**
     * product StockItem
     *
     * @var Magento\CatalogInventory\Api\StockStateInterface
     */
	 protected $_stockItem;

	
	public function __construct(
		CollectionFactory $productCollectionFactory,
		ObjectManagerInterface $interface,
		AdditionalFactory $additional,
		ProductRepository $productRepository,
		StockItemRepository $stockItem
	) {
		$this->_productCollectionFactory = $productCollectionFactory; 
        $this->_object = $interface;
		$this->_additional = $additional;
		$this->_productRepository = $productRepository;
		$this->_stockItem = $stockItem;
	}



    public function getCustomerConfigCollection()
    {
		$customerData = $this->getCustomerSession();
		$customerId = $customerData->getId();
		$configCollection = $this->_additional->create()->getCollection()
														->addFieldToSelect('*')
														->addFieldToFilter('customer_id',$customerId);
        return $configCollection;
    }
		
	public function getProductCollection()
	{
		$_configCollection = $this->getCustomerConfigCollection();
		$data = $_configCollection->getData();
		$allProductData = json_decode($data[0]['product_information'], true);
		$collection = $this->_productCollectionFactory->create();
		$collection->addAttributeToSelect('*')
				   ->addAttributeToFilter('entity_id', array('in' => $allProductData['product_id']))
				   ->load();
		return $collection;
	}
	
	public function getCustomerSession(){
        $customerSession = $this->_object->create('Magento\Customer\Model\Session');
		if($customerSession->isLoggedIn()){
		    return $customerSession->getCustomerData();
		}    
    }
	
	/**
     * Get Product Stock Information
     *
     * @return Stco Information
     */
    public function getQty($id = null)
    {
        return $this->_stockItem->get($id)->getQty();
    }
	
}
?>