var config = {
    "map": {
        "*": {
            "Magento_Checkout/js/model/shipping-save-processor/default" : "Signature_Deliverydate/js/shipping-save-processor-default-override",
            "Signature_Deliverydate/js/delivery-date" : "Signature_Deliverydate/js/delivery-date"
        }
    }
};