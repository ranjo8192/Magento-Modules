<?php

namespace Signature\Deliverydate\Block\Adminhtml\Holiday;

use Magento\Backend\Block\Widget\Grid as WidgetGrid;

/**
 * Class Grid
 * @package Signature\Deliverydate\Block\Adminhtml\Holiday
 */
class Grid extends WidgetGrid
{

}