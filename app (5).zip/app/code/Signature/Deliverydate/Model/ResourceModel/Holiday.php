<?php


namespace Signature\Deliverydate\Model\ResourceModel;

/**
 * Class Holiday
 * @package Signature\Deliverydate\Model\ResourceModel
 */
class Holiday extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{

    /**
     * Define main table
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('signature_deliverydate_holiday', 'id');
    }

}