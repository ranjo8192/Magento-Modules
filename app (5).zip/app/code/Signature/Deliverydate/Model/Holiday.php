<?php

namespace Signature\Deliverydate\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * Class Holiday
 * @package Signature\Deliverydate\Model
 */
class Holiday extends AbstractModel
{
    /**
     * Initialize holiday model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Signature\Deliverydate\Model\ResourceModel\Holiday');
    }
}