<?php
namespace Signature\Customer\Block;
use \Magento\Framework\View\Element\Template\Context;
use \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;

class NewOrder extends \Magento\Framework\View\Element\Template
{ 
   /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
	protected $_productCollectionFactory;
	
	public function __construct(
		Context $context,
		CollectionFactory $productCollectionFactory,
		array $data = []
	) {
		$this->_productCollectionFactory = $productCollectionFactory;    
		parent::__construct($context, $data);
	}

	public function getProductCollection() {
		$collection = $this->_productCollectionFactory->create();
		$collection->addAttributeToSelect('*');
		$collection->setPageSize(5); 
		return $collection;
	}
}