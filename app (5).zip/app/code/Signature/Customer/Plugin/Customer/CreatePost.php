<?php
namespace Signature\Customer\Plugin\Customer;
use Magento\Customer\Model\AddressFactory;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\App\Action\Context;

class CreatePost
{	
	
	/**
	 * @var \Magento\Customer\Model\AddressFactory
	 */
	protected $addressFactory;
	
	/**
	 * @var \Magento\Customer\Model\CustomerFactory
	 */
	protected $customerFactory;
	
    public function __construct(
		 Context $context,
		 AddressFactory $addressFactory,
		 CustomerFactory $customerFactory
    ) {
        $this->_request = $context->getRequest();
        $this->_response = $context->getResponse();
        $this->resultRedirectFactory = $context->getResultRedirectFactory();
        $this->resultFactory = $context->getResultFactory();
		$this->addressFactory = $addressFactory;
		$this->customerFactory = $customerFactory;

    }

    public function afterExecute(\Magento\Customer\Controller\Account\CreatePost $subject, $proceed)
    {    
	
		$post = $this->_request->getPostValue();
		$customerData = $this->customerFactory->create();
		$customerObj  =	$customerData->getCollection()
		                          ->addAttributeToSelect('entity_id')
								  ->addAttributeToSort('entity_id','desc');
		///echo '<pre>';print_r(get_class_methods($customerObj));die;						  
		if(empty($post['sameShipping']) && $post['profile_group']!=5){
			if($customerObj->getSize()){					
				$data = $customerObj->getFirstItem();
				$customerId =  $data->getId();
				$address = $this->addressFactory->create();
				$address->setCustomerId($customerId)
						->setParentId($customerId)
						->setFirstname($post['firstname'])			 
						->setLastname($post['lastname'])	
						->setRegionId($post['bregion_id'])
						->setRegion($post['bregion'])						
						->setCountryId($post['bcountry_id'])			 
						->setPostcode($post['bpostcode'])			 
						->setCity($post['bcity'])			 
						->setTelephone($post['telephone'])			 		 	 
						->setStreet($post['bstreet'][0]." ".$post['bstreet'][1])			 
						->setIsDefaultBilling('1')			 
						->setIsDefaultShipping('0')			 
						->setSaveInAddressBook('1');
				
				$address->save();

			}
		}
		return $proceed;

    }
}