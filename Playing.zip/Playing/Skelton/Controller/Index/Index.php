<?php
 
namespace Playing\Skelton\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Index extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
    protected $context;
	protected $_coreSession;
	
    public function __construct(
	Context $context,
	\Magento\Framework\View\Result\PageFactory $resultPageFactory,
	\Magento\Customer\Model\Session $customerSession
	)
    {
		
        $this->_resultPageFactory = $resultPageFactory;
        $this->_context = $context;
		$this->_customerSession = $customerSession;
        parent::__construct($context);
    }
 
    public function execute()
    {

		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$coreSession = $objectManager->get('Magento\Framework\Session\SessionManagerInterface'); 

		$coreSession->start();
		// Set Session
		$coreSession->setData('shoulder', $_POST['shoulder']);
		$coreSession->setData('chest', $_POST['chest']);
		$coreSession->setData('bust', $_POST['bust']);
		$coreSession->setData('shoulder_to_waist', $_POST['shoulder_to_waist']);
		$coreSession->setData('waist', $_POST['waist']);
		$coreSession->setData('waist_to_hip', $_POST['waist_to_hip']);
		$coreSession->setData('sleave_length', $_POST['sleave_length']);
		$coreSession->setData('hips', $_POST['hips']);
		$coreSession->setData('crust_depth_line', $_POST['crust_depth_line']);
		$coreSession->setData('waist_to_knee', $_POST['waist_to_knee']);
		$coreSession->setData('knee_line', $_POST['knee_line']);
		$coreSession->setData('high_ankle', $_POST['high_ankle']);
		$coreSession->setData('arm_depth', $_POST['arm_depth']);
		$coreSession->setData('back_width', $_POST['back_width']);
		$coreSession->setData('dola', $_POST['dola']);
		$coreSession->setData('nap_to_waist', $_POST['nap_to_waist']);
		$coreSession->setData('wrist', $_POST['wrist']);
		$coreSession->setData('body_rise', $_POST['body_rise']);
		$coreSession->setData('waist_to_floor', $_POST['waist_to_floor']);
echo $coreSession->getData('shoulder');
        $resultPage = $this->_resultPageFactory->create();
		return $resultPage;
		
    }
}