<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Playing\Skelton\Observer;

use Magento\Framework\Event\ObserverInterface;

class Process implements ObserverInterface
{
    /**
     * Set forced canCreditmemo flag
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$coreSession = $objectManager->get('Magento\Framework\Session\SessionManagerInterface'); 

		//$coreSession->start();
		$session['shoulder'] = $coreSession->getData('shoulder');
		$session['chest'] = $coreSession->getData('chest');
		$session['bust'] = $coreSession->getData('bust');
		$session['shoulder_to_waist'] = $coreSession->getData('shoulder_to_waist');
		$session['waist'] = $coreSession->getData('waist');
		$session['waist_to_hip'] = $coreSession->getData('waist_to_hip');
		$session['sleave_length'] = $coreSession->getData('sleave_length');
		$session['hips'] = $coreSession->getData('hips');
		$session['crust_depth_line'] = $coreSession->getData('crust_depth_line');
		$session['waist_to_knee'] = $coreSession->getData('waist_to_knee');
		$session['knee_line'] = $coreSession->getData('knee_line');
		$session['high_ankle'] = $coreSession->getData('high_ankle');
		$session['arm_depth'] = $coreSession->getData('arm_depth');
		$session['back_width'] = $coreSession->getData('back_width');
		$session['dola'] = $coreSession->getData('dola');
		$session['nap_to_waist'] = $coreSession->getData('nap_to_waist');
		$session['wrist'] = $coreSession->getData('wrist');
		$session['body_rise'] = $coreSession->getData('body_rise');
		$session['waist_to_floor'] = $coreSession->getData('waist_to_floor');
		$data = json_encode($session);
		$order = $observer->getEvent()->getOrder();
		$order->setFormsJson($data);
        return $this;
		
    }
}