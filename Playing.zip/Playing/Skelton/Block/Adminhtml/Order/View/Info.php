<?php
namespace Playing\Skelton\Block\Adminhtml\Order\View;

class Info extends \Magento\Sales\Block\Adminhtml\Order\View\Info {
	protected $registry;
	protected $_order;
	protected $scopeConfig;
	protected $_objectManager;

    public function __construct(\Magento\Framework\Registry $registry, \Magento\Framework\ObjectManagerInterface $objectManager, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig){
		$this->registry = $registry;
		$this->_objectManager = $objectManager;
		$this->scopeConfig = $scopeConfig;
		$this->_order = $this->registry->registry('current_order');
    }

    public function toHtml(){

		$order = $this->_order;
		return $order->getFormsJson();
		
	}
}
