<?php
namespace Magepapa\Hello\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
 
/**
 * Webkul Hello Landing page Index Controller.
 */ 
class Index extends Action
{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Data\Form\FormKey $formKey,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->formKey = $formKey;
        $this->resultPageFactory = $resultPageFactory;
    }
 
    /**
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
      $resultPage = $this->resultPageFactory->create();
 
       return $resultPage;
    }
}