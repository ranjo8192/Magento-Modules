<?php

namespace Signature\Customers\Observer;


use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Registry;
use Magento\Framework\App\RequestInterface;

class CheckApproval implements ObserverInterface
{
    protected $coreRegistry;
	/**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $_request;
    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    public function __construct(
		Registry $registry,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
		\Magento\Store\Model\StoreManagerInterface $storeManager
		)
		{
			$this->coreRegistry = $registry;
			$this->_request = $request;
			$this->_transportBuilder = $transportBuilder;
			$this->_storeManager = $storeManager;
			//parent::__construct($context);
		}

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		//echo "<pre>";
		//print_r(get_class_methods($observer));	
		$event = $observer->getEvent();
		$customer = $event->getCustomer();
		$name = $customer->getFirstName();
		$email = $customer->getEmail();
		$id = $customer->getId();
		//echo $id,$email;
		//print_r(get_class_methods($customer));
		$attributes = $customer->getCustomAttributes();
		$approvalStatus = $attributes['approve_account']->getValue();
		
		if($approvalStatus = "1"){
		$store = $this->_storeManager->getStore()->getId();
        $transport = $this->_transportBuilder->setTemplateIdentifier('account_approval_email_custom')
            ->setTemplateOptions(['area' => 'adminhtml', 'store' => $store])
            ->setTemplateVars(
                [
                    'store' => $this->_storeManager->getStore(),
                ]
            )
            ->setFrom('general')
            // you can config general email address in Store -> Configuration -> General -> Store Email Addresses
            ->addTo($email, $name)
            ->getTransport();
        $transport->sendMessage();
        return $this;
		}
	}
}