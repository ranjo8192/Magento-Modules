<?php
namespace Magepapa\Cataloglistview\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Checkout\Model\Cart;
use Magento\Catalog\Model\ProductFactory;
use Magento\Framework\Data\Form\FormKey;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
 
/**
 * Webkul Hello Landing page Index Controller.
 */ 
class Index extends Action
{

    /**
     * @var PageFactory
     */
    protected $_resultPageFactory;
    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $_formKey;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
	 
	 /**
     * @var \Magento\Checkout\Model\Cart
     */
    private $_cart;
	/**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    private $_product;
	
	/**
     * @var \Magento\ConfigurableProduct\Model\Product\Type\Configurable
     */
    private $_configurable;
	
	
	
    public function __construct(
        Context $context,
        FormKey $formKey,
        PageFactory $resultPageFactory,
		Cart $cart, 
		ProductFactory $product,
		Configurable $configurable
    ) {
        parent::__construct($context);
        $this->_formKey = $formKey;
        $this->_resultPageFactory = $resultPageFactory;
		$this->_cart = $cart;
		$this->_product = $product;
		$this->_configurable = $configurable;
    }
 
    /**
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        
        $post = $this->getRequest()->getPost();
		if(!empty($post)){
			
				$configProductId = $post['product'];
				
				// Getting simple product id from post['option_value']
				$simpleProducId = $post['option_value'];

				// Load parent product by Id
				$_product = $this->_product->create()->load($configProductId);
				
				//load child product by Id
				$_childProductId = $this->_product->create()->load($simpleProducId);
				$simpleProducPrice = $_childProductId->getPrice();
				
				//get parent product configurable attributes
				$productAttributeOptions = $this->_configurable->getConfigurableAttributesAsArray($_product);
				
				$options = []; //Empty array
				foreach($productAttributeOptions as $option){
					$options[$option['attribute_id']] = $_childProductId->getData($option['attribute_code']);
				}
				// array of all required data
				$params = array(
				'form_key' => $this->_formKey->getFormKey(),
				'product' =>$configProductId,//product Id
				'price' =>$simpleProducPrice,
				'super_attribute' =>$options,
				'qty'   =>1
				);
				$this->_cart->addProduct($_product, $params);
				}
				$this->_cart->save();
				$this->_redirect('checkout/cart/');
    }
}