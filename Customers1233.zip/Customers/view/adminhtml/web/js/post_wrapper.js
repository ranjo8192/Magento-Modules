/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'jquery',
	'Magento_Ui/js/modal/confirm',
    'mage/translate',
	'popuprequirejs',
], function ($, confirm) {
    'use strict';
 return function(config, element) {
	//alert(config.full_action_name);
	 if(config.full_action_name == 0){
	 $(document).on('click', '.action-secondary.action-dismiss', function(){
		 location.reload();
		 //$('#tab_block_customer_edit_tab_customer_configuration').click();
	 })
	 // alert(config.full_action_name);
	 $('#save_and_continue, #save').on("click.myEvent", function(e) {
			var $that = $(this);
			$that.off('click.myEvent');
			e.preventDefault();
			e.stopImmediatePropagation();
			var msg = $.mage.__('Are you sure to approve this doctor before saving configurations related to products, payment and shipping methods?');
		
			confirm({
				'content': msg,
				'actions': {
					confirm: function () {
						$that.trigger("click");
					}
				}
			});

			return false;
		}); 
        
    }
    }
 
	   function getForm(url) {
        return $('<form>', {
            'action': url,
            'method': 'POST'
        }).append($('<input>', {
            'name': 'form_key',
            'value': window.FORM_KEY,
            'type': 'hidden'
        }));
    }

   
});
