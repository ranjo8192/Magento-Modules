<?php
namespace Signature\CustomerOrder\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Checkout\Model\Cart;
use Magento\Catalog\Model\ProductFactory;
use Magento\Framework\Controller\ResultFactory;
use Psr\Log\LoggerInterface;

class Index extends \Magento\Customer\Controller\AbstractAccount {
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    private $pageFactory;

    /**
     * @var \Magento\Checkout\Model\Cart
     */
    private $cart;
	/**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    private $product;
	/**
     * @var \Magento\Framework\Controller\ResultFactory
     */
    private $resultRedirect;
	/**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;
    /**
     * NewOrder constructor.
     * @param Context $context
     * @param PageFactory $pageFactory
	 * @param PageFactory $cart
	 * @param PageFactory $product
	 * @param PageFactory $result
	 * @param PageFactory $logger
     */
    public function __construct(
        Context $context,
        PageFactory $pageFactory,
		Cart $cart, 
		ProductFactory $product,
		ResultFactory $result,
		LoggerInterface $logger
    )
    {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
		$this->request = $context->getRequest();
		$this->cart = $cart;
		$this->product = $product;
		$this->resultRedirect = $result;
		$this->logger = $logger;
    }

    public function execute()
    {
	
		$post = $this->request->getPostValue();
		$params = array();
		if(!empty($post['product_check']))
		{	
			for($i=0;$i<count($post['product_check']);$i++)
			{
				$params[]=array('form_key'=>$post['form_key'],'product'=>$post['product_check'][$i],'qty'=>(int)$post['qty'][$post['product_check'][$i]], 'price'=>$post['productprice'][$post['product_check'][$i]]);
				
			}
		}
		
		$resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
		try{
			if(!empty($params)){
				foreach ($params as $product) {
					$_product = $this->product->create()->load($product['product']);

					$this->cart->addProduct($_product, $product);
					
					}
					$this->cart->save();
			}
			$quote = $this->cart->getQuote();
            // $quote->setData('fee', 0.00);
            $quote->setData('delivery_date', $post['delivery-date']);
            $quote->save();
			
			$resultRedirect->setUrl('checkout/cart/');  
		}catch(Exception $e) {
		  $this->logger->info($e->getMessage());
		  $resultRedirect->setUrl('*/*/');
		}
		return $resultRedirect; 
    }
	
}
?>