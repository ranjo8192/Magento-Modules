<?php

namespace Signature\CustomerOrder\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Signature\Extrafee\Helper\Data;

class CartTime extends Action {

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    private $timezone;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var \Signature\CustomerOrder\Helper\Data
     */
    private $helperData;

    /**
     * NewOrder constructor.
     * @param Context $context
     * @param TimezoneInterface $timeZone
     * @param JsonFactory $JsonFactory
     */
    public function __construct(
    Context $context, Data $helperData, ScopeConfigInterface $scopeConfig, TimezoneInterface $timeZone, JsonFactory $JsonFactory
    ) {
        parent::__construct($context);
        $this->request = $context->getRequest();
        $this->timezone = $timeZone;
        $this->resultJsonFactory = $JsonFactory;
        $this->scopeConfig = $scopeConfig;
        $this->helperData = $helperData;
    }

    /**
     * Execute function for config processing fee and text message.
     * @param no
     * @retrun array
     */
    public function execute() {
        $result = $this->resultJsonFactory->create();
        
        $processFee = $this->helperData->getProcessFee();
        $start_time = $this->helperData->getStartTime();
        $end_time = $this->helperData->getEndTime();
        $closed_time = $this->helperData->getClosedTime();
        
        $post = $this->request->getPostValue();
        
        $message = '';
        $price = '';

        $current_date = $this->timezone->date()->format('Y-m-d');

        // Create logic for add processing fee
        if ((strtotime($current_date) + 86400) == strtotime($post['delivery_date'])) {

            $current_date_time = strtotime($this->timezone->date()->format('Y-m-d H:i'));

            $start_date_time = strtotime($current_date . ' ' . $start_time);
            $end_date_time = strtotime($current_date . ' ' . $end_time);
            $closed_date_time = strtotime($current_date . ' ' . $closed_time);
                        
            if ($start_date_time < $current_date_time && $current_date_time <= $end_date_time) {
                $message = __('A ' . $processFee . ' expedited processing fee will be added to your order.'); // Add text message when order between 12:00 - 15:00 for next-day delivery
                $price = $processFee;
            } else if ($end_date_time < $current_date_time && $current_date_time <= $closed_date_time) {
                $message = __('Please call the office at 972-807-5916 to see if we can fill your order.'); // Add text message when order between 15:00 - 17:00 for next-day delivery
            } else if ($current_date_time > $closed_date_time) {
                $message = __('We closed at 5:00 PM CST today. We will be unable to ship this order for delivery tomorrow. Please select a different delivery date.');
                // Add text message when order after 17:00 for next-day delivery
            }
        }
        $result->setData(["html" => $message, "price" => $price]);
        return $result;
    }

}

?>