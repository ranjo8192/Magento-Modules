<?php
namespace Signature\CustomerOrder\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Checkout\Model\Cart;
use Magento\Checkout\Model\Session as CheckoutSession;
use Signature\Extrafee\Helper\Data;

class AddFee extends Action {
	
	/**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
	 
    private $resultJsonFactory;
    
    /**
     * @var \Magento\Checkout\Model\Cart
     */
    private $cart;
    
    /** @var CheckoutSession */
    protected $checkoutSession;
    
    /**
     * @var \Signature\CustomerOrder\Helper\Data
     */
    private $helperData;
    
    /**
     * NewOrder constructor.
     * @param Context $context
	 * @param JsonFactory $JsonFactory
     */
    public function __construct(
        Context $context,
            Data $helperData,
            JsonFactory $JsonFactory,
            Cart $cart,
            CheckoutSession $checkoutSession
    )
    {
        parent::__construct($context);
		$this->request = $context->getRequest();
		$this->resultJsonFactory = $JsonFactory;
                $this->cart = $cart;
                $this->checkoutSession = $checkoutSession;
                $this->helperData = $helperData;
    }

    public function execute()
    {
        $quote = $this->checkoutSession->getQuote();
        
        $processFee = $this->helperData->getProcessFee();
        
        $response = '';
        $result = $this->resultJsonFactory->create();
        try {
            $quote->setData('fee', $processFee);
            $quote->save();
            if ($quote->getData('fee') == $processFee) {
                $response = true;
            } else {
                $response = false;
            }
        } catch (Exception $e) {
            $response = false;
        }
            
        $result->setData(["response"=>$response]);
        return $result;
    }
}
?>