<?php
namespace Signature\AdditionalContact\Setup;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**	
 * @var schema for create additional_contact table
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
    * {@inheritdoc}
    * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
    */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
          /**
          * Create table 'additional_contact'
          */
          $table = $setup->getConnection()
              ->newTable($setup->getTable('additional_contact'))
              ->addColumn(
                  'additional_id',
                  \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                  null,
                  ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                  'Additional ID'
              )
			  ->addColumn(
                  'customer_id',
                  \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                  null,
                  ['unsigned' => true, 'nullable' => false, 'unique' => true],
                  'Customer ID'
              )
              ->addColumn(
                  'first_name',
                  \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                  255,
                  ['nullable' => false, 'default' => ''],
                    'First Name'
              )
			  ->addColumn(
                  'last_name',
                  \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                  255,
                  ['nullable' => false, 'default' => ''],
                    'Last Name'
              )
			  ->addColumn(
                  'email',
                  \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                  255,
                  ['nullable' => false, 'default' => ''],
                    'Email'
              )
			  ->addColumn(
                  'tracking_information',
                  \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                  255,
                  ['nullable' => false, 'default' => ''],
                    'Tracking Information'
              )
			  ->addIndex(
				$setup->getIdxName(
                $setup->getTable('additional_contact'),
                ['customer_id'],
                \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
            ),
            ['customer_id'],
            ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE]
        )->setComment("Additional Contact Table");
          $setup->getConnection()->createTable($table);
      }
}