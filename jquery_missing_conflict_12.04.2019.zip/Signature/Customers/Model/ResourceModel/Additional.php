<?php
namespace Signature\Customers\Model\ResourceModel;
class Additional extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('customer_configuration', 'id');   //here "additional_contact" is table name and "additional_id" is the primary key of custom table
    }
}