<?php
namespace Signature\Customers\Controller\Adminhtml\Index;
use Signature\Customers\Model\AdditionalFactory;
use Magento\Customer\Controller\RegistryConstants;
 
class CustomerConfigurationPost extends \Magento\Backend\App\Action
{
	/**
     *
     * @var Signature\Customers\Model\AdditionalFactory
     */
	protected $_additional;
	
	/**
     * Customer Session
     * @var \Magento\Customer\Model\Session
     */
	protected $_customerSession;
	/**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;
	
	/**
     * CreatePost constructor.
     * @param Context $context
     * @param AdditionalFactory $additional
     * @param Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\Registry $registry
     */
	
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		AdditionalFactory $additional,
		\Magento\Customer\Model\Session $customerSession,
		\Magento\Framework\Registry $registry
    )
	{
		
       parent::__construct($context);
	   $this->_additional = $additional;
	   $this->_customerSession = $customerSession;
	   $this->_coreRegistry = $registry;
    }
   
    public function execute()
    {
		$post = $this->getRequest()->getPostValue();
		$customerId=$post['customer_id'];

		try {

			$collection = $this->_additional->create()->getCollection()
													  ->addFieldToSelect(['customer_id','id'])
												      ->addFieldToFilter('customer_id',$customerId);
			$data = $collection->getData();

			$productsInformation = json_encode($post['products'], true);
			$paymentInformation = json_encode($post['paymentmethods'], true);
			$shippingInformation = json_encode($post['shippingmethods'], true);
			$customerConfig = $this->_additional->create();
			if(count($collection) > 0){
				$data[0] =  $collection->getFirstItem();
				$id  = $data[0]->getId();
				$customerConfig->load($id);
			}
			$customerConfig->setCustomerId($post['customer_id']);
			$customerConfig->setProductInformation($productsInformation);
			$customerConfig->setShippingMethods($shippingInformation);	
			//$customerConfig->setEmail($email);
			$customerConfig->setPaymentMethods($paymentInformation);
			$customerConfig->save();	
			
			
			$this->messageManager->addSuccess(__('Customer Configuration has been saved successfully.'));
			$this->_redirect('customer/index/index');
			return;
			} catch (\Exception $e) {
			$this->messageManager->addError(__('We can\�t process your request right now. Sorry, check your details and try again.'));
			$this->_redirect('customer/index/index');
			return;
			}
		}
}