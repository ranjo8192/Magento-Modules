<?php


namespace Signature\Deliverydate\Model\Sales\Order\Email;

use Magento\Sales\Model\Order\Email\Container\Template;

/**
 * Class SenderBuilderPlugin
 * @package Signature\Deliverydate\Model\Sales\Order\Email
 */
class SenderBuilderPlugin
{

    /**
     * @var Template
     */
    protected $templateContainer;

    /**
     * @param Template $templateContainer
     */
    public function __construct(
        Template $templateContainer
    ) {
        $this->templateContainer = $templateContainer;
    }


    /**
     * @param $subject
     * @param \Closure $proceed
     * @return mixed
     */
    public function aroundSend($subject, \Closure $proceed)
    {
        $vars = $this->templateContainer->getTemplateVars();
        $order = $vars['order'];
        $order->setAppendDeliveryDate(true);
        $returnValue = $proceed();
        $order->setAppendDeliveryDate(false);
        return $returnValue;
    }
}