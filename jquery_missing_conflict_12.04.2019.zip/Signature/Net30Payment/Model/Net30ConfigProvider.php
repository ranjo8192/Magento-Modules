<?php

namespace Signature\Net30Payment\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Signature\Net30Payment\Model\Config;


class Net30ConfigProvider implements ConfigProviderInterface
{
	const CODE = 'net30';
    
    private $config;

    /**
     * @param \Magento\Vault\Model\ResourceModel\PaymentToken\CollectionFactory $tokenCollection
     * @param \Magento\Customer\Model\Session $session
     * @param \Psr\Log\LoggerInterface $logs
     * @param \Vesta\Payment\Model\CreditCardData $creditCards
     * @param \Vesta\Payment\Gateway\Config\PaymentConfig $config
     */
    public function __construct(Config $config) {
        $this->config = $config;
    }

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */

    public function getConfig()
    {
        return [
            'payment' => [
                self::CODE => [
                    'fixedamount' => "testtt",
                    'instruction' => $this->config->getInstructions()
                ]
            ]
        ];
    }
}
