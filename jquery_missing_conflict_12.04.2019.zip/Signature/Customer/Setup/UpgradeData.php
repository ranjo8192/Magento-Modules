<?php

namespace Signature\Customer\Setup;

use Magento\Eav\Setup\EavSetupFactory;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

use Magento\Eav\Model\Config;

class UpgradeData implements UpgradeDataInterface
{
	/**
	 * @var \Magento\Eav\Setup\EavSetupFactory
	 */
	 
    private $eavSetupFactory;
	
	/**
	 * @var \Magento\Eav\Model\Config
	 */
	 
    private $eavConfig;
	
	/**
	 * @var \Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory
	 */
    private $attributeSetFactory;

    public function __construct(EavSetupFactory $eavSetupFactory, Config $eavConfig, AttributeSetFactory $attributeSetFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->eavConfig       = $eavConfig;
        $this->attributeSetFactory       = $attributeSetFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
	    
	   /**
		* @custom field Rep Name 
		*/
       if (version_compare($context->getVersion(), '1.2.3') < 0) {

            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $customerEntity = $this->eavConfig->getEntityType('customer');
            $attributeSetId = $customerEntity->getDefaultAttributeSetId();
			$eavSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, "rep_name");
            $attributeSet = $this->attributeSetFactory->create();
            $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);
             
            $eavSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'rep_name', [
                'user_defined' => true,
                'position' => 499,
                'type' => 'varchar',
                'label' => 'Rep Name',
                'input' => 'select',
                'sort_order' => 200,
                'default' => '',
                'visible' => true,
                'required' => false,
				'system' => 0,
				'source' => 'Signature\Customer\Model\Config\Source\SalesrepOptions',
				'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL
            ]);
             
            $attribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'rep_name')
                ->addData([
                    'attribute_set_id' => $attributeSetId,
                    'attribute_group_id' => $attributeGroupId,
                    'used_in_forms' => ['customer_account_create', 'customer_account_edit','adminhtml_customer','adminhtml_checkout','checkout_register','customer_address_edit','customer_register_address'],
                ]);
             
            $attribute->save();
        }
		
		/**
		 * @custom field Docotor NPI# Number
		 */
		if (version_compare($context->getVersion(), '1.2.2') < 0) {

            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $customerEntity = $this->eavConfig->getEntityType('customer');
            $attributeSetId = $customerEntity->getDefaultAttributeSetId();
            $attributeSet = $this->attributeSetFactory->create();
            $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);
			$eavSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, "doctor_npi");
             
            $eavSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'doctor_npi', [
                'user_defined' => true,
                'position' => 499,
                'type' => 'varchar',
                'label' => 'NPI#',
                'input' => 'text',
                'sort_order' => 200,
                'default' => '',
                'visible' => true,
                'required' => false,
				'system' => 0
            ]);
             
            $attribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'doctor_npi')
                ->addData([
                    'attribute_set_id' => $attributeSetId,
                    'attribute_group_id' => $attributeGroupId,
                    'used_in_forms' => ['customer_account_create', 'customer_account_edit','adminhtml_customer','adminhtml_checkout','checkout_register','customer_address_edit','customer_register_address'],
                ]);
             
            $attribute->save();
        }
		
		/**
		* @custom field Other information Description  
		*/
		if (version_compare($context->getVersion(), '1.0.12') < 0) {

            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $customerEntity = $this->eavConfig->getEntityType('customer');
            $attributeSetId = $customerEntity->getDefaultAttributeSetId();
            $attributeSet = $this->attributeSetFactory->create();
            $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);
			$eavSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, "other_info_desc");
             
            $eavSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'other_info_desc', [
                'user_defined' => true,
                'position' => 500,
                'type' => 'text',
                'label' => 'Other Information Description',
                'input' => 'textarea',
                'sort_order' => 201,
                'default' => '',
                'visible' => true,
                'required' => false,
				'system' => 0
            ]);
             
            $attribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'other_info_desc')
                ->addData([
                    'attribute_set_id' => $attributeSetId,
                    'attribute_group_id' => $attributeGroupId,
                    'used_in_forms' => ['customer_account_create', 'customer_account_edit','adminhtml_customer','adminhtml_checkout','checkout_register','customer_address_edit','customer_register_address'],
                ]);
             
            $attribute->save();
        }
		
		/**
		* @custom field Doctor  NPI# status 
		*/
		if (version_compare($context->getVersion(), '1.2.1') < 0) {

            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $customerEntity = $this->eavConfig->getEntityType('customer');
            $attributeSetId = $customerEntity->getDefaultAttributeSetId();
            $attributeSet = $this->attributeSetFactory->create();
            $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);
			$eavSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, "npi_status");
             
            $eavSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'npi_status', [
                'user_defined' => true,
                'position' => 502,
                'type' => 'varchar',
                'label' => 'Docotor NPI# Status',
                'input' => 'text',
                'sort_order' => 202,
                'default' => '',
                'visible' => true,
                'required' => false,
				'system' => 0
            ]);
             
            $attribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'npi_status')
                ->addData([
                    'attribute_set_id' => $attributeSetId,
                    'attribute_group_id' => $attributeGroupId,
                    'used_in_forms' => ['customer_account_create', 'customer_account_edit','adminhtml_customer','adminhtml_checkout','checkout_register','customer_address_edit','customer_register_address'],
                ]);
             
            $attribute->save();
        }
    }
}