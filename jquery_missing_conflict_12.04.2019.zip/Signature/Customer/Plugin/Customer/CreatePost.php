<?php
namespace Signature\Customer\Plugin\Customer;
use Magento\Customer\Model\AddressFactory;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\App\Action\Context;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Psr\Log\LoggerInterface;
use Signature\Customers\Model\AdditionalFactory;

class CreatePost
{	
    /**
	 * @var \Magento\Customer\Api\CustomerRepositoryInterface
	 */
	private $customerRepository;
	/**
	 * @var \Magento\Customer\Model\AddressFactory
	 */
	protected $addressFactory;
	
	/**
	 * @var \Magento\Customer\Model\CustomerFactory
	 */
	protected $customerFactory;
	
	/**
     * @var \Psr\Log\LoggerInterface
     */
		private $logger;
		
		/**
     *
     * @var Signature\Customers\Model\AdditionalFactory
     */
		protected $_additional;
	/**
     * CreatePost constructor.
     * @param Context $context
     * @param AddressFactory $addressFactory
     * @param CustomerFactory $customerFactory
     * @param CustomerRepositoryInterface $customerRepository
		 * @param AdditionalFactory $additional
     */
    public function __construct(
		 Context $context,
		 AddressFactory $addressFactory,
		 CustomerFactory $customerFactory,
		 CustomerRepositoryInterface $customerRepository,
		 LoggerInterface $logger,
		 AdditionalFactory $additional
    ) {
        $this->_request = $context->getRequest();
        $this->_response = $context->getResponse();
        $this->resultRedirectFactory = $context->getResultRedirectFactory();
        $this->resultFactory = $context->getResultFactory();
				$this->addressFactory = $addressFactory;
				$this->customerFactory = $customerFactory;
				$this->customerRepository = $customerRepository;
				$this->logger = $logger;
				$this->_additional = $additional;

    }

    public function afterExecute(\Magento\Customer\Controller\Account\CreatePost $subject, $proceed)
    {    
	
		$post = $this->_request->getPostValue();
		$customerData = $this->customerFactory->create();
		$customerObj  =	$customerData->getCollection()
						->addAttributeToSelect('entity_id')
						->addAttributeToSort('entity_id','desc');
	try{
		if($customerObj->getSize()){					
			$data = $customerObj->getFirstItem();
			$customerId =  $data->getId();
			$customer = $this->customerRepository->getById($customerId); 
			switch($post['profile_group'])
			{
				case 1:
				$group_id = 4;
				break;
				
				case 2:
				$group_id = 5;
				break;
				
				case 3:
				$group_id = 6;
				break;

			}		
			// Set default group Id
			$customer->setGroupId($group_id);    
			$this->customerRepository->save($customer);

			//set customer configuration table data
			if($group_id == 4){
			$this->customerConfigurationSave($customerId); }


			if(empty($post['sameShipping']) && $group_id != 5){
				$address = $this->addressFactory->create();
				$address->setCustomerId($customerId)
						->setParentId($customerId)
						->setFirstname($post['firstname'])			 
						->setLastname($post['lastname'])	
						->setRegionId($post['bregion_id'])
						->setRegion($post['bregion'])						
						->setCountryId($post['bcountry_id'])			 
						->setPostcode($post['bpostcode'])			 
						->setCity($post['bcity'])			 
						->setTelephone($post['telephone'])			 		 	 
						->setStreet($post['bstreet'][0]." ".$post['bstreet'][1])			 
						->setIsDefaultBilling('1')			 
						->setIsDefaultShipping('0')			 
						->setSaveInAddressBook('1');
				$address->save();
			}
		}
		}catch(Exception $e) {
		  $this->logger->info($e->getMessage());
		  $this->messageManager->addErrorMessage(__('Something went wrong please check your details & try again!'));
		  
		}
		return $proceed;
    }
	
		
		public function customerConfigurationSave($customerId)
		{

					try {
						$paymentArray = array('payment_information'=>array('Pay Via ACH'));
						$shippingArray = array('shipping_information'=>array('FedEx Priority Overnight','FedEx First Overnight'));

						$paymentInformation = json_encode($paymentArray, true);
						$shippingInformation = json_encode($shippingArray, true);
						$customerConfig = $this->_additional->create();
						$customerConfig->setCustomerId($customerId);
						$customerConfig->setShippingMethods($shippingInformation);	
						//$customerConfig->setEmail($email);
						$customerConfig->setPaymentMethods($paymentInformation);
						$customerConfig->setApproveStatus(2);
						$customerConfig->save();	

						return;
					} catch (\Exception $e) {
						return;
				}
				return $proceed;
			}
}