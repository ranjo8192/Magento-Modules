<?php
 
namespace Playing\Skelton\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Index extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
    protected $context;
 
    public function __construct(Context $context, \Magento\Framework\View\Result\PageFactory $resultPageFactory)
    {
		
        $this->_resultPageFactory = $resultPageFactory;
        $this->_context = $context;
        parent::__construct($context);
    }
 
    public function execute()
    {
		$post = $this->_context->getRequest()->getParams();
		
			$shoulder  =				$post['shoulder'];
			$chest   =					$post['chest'];
			$bust   =					$post['bust'];
			$shoulder_to_waist   =		$post['shoulder_to_waist'];
			$waist   =					$post['waist'];
			$waist_to_hip   =			$post['waist_to_hip'];
			$sleave_length   =			$post['sleave_length'];
			$hips   =					$post['hips'];
			$crust_depth_line   =		$post['crust_depth_line'];
			$waist_to_knee   =			$post['waist_to_knee'];
			$knee_line   =				$post['knee_line'];
			$high_ankle   =				$post['high_ankle'];
			$neck_size   =				$post['neck_size'];
			$arm_depth   =				$post['arm_depth'];
			$back_width   =				$post['back_width'];
			$dola   =					$post['dola'];
			$nap_to_waist   =			$post['nap_to_waist'];
			$wrist   =					$post['wrist'];
			$body_rise   =				$post['body_rise'];
			$waist_to_floor   =			$post['waist_to_floor'];
			
		echo "<pre>"; print_r($post); die;
        $resultPage = $this->_resultPageFactory->create();
        return $resultPage;
    }
}