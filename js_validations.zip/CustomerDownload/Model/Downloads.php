<?php
/**
 * Copyright © 2017 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Signature\CustomerDownload\Model;

/**
 * Class Downloads
 * @package Signature\CustomerDownload\Model
 */
class Downloads extends \Magento\Framework\Model\AbstractExtensibleModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Signature\CustomerDownload\Model\ResourceModel\Downloads');
    }

    /**
     * @return array
     */
    public function getCustomAttributesCodes()
    {
        return array('pdf_id', 'pdf_name', 'pdf_detail');
    }
}