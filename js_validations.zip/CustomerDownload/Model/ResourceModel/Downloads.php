<?php
/**
 * Copyright © 2017 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Signature\CustomerDownload\Model\ResourceModel;

/**
 * Class Downloads
 * @package Signature\CustomerDownload\Model\ResourceModel
 */
class Downloads extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Constructor
     */
    protected function _construct()
    {
        $this->_init('customer_downloads', 'pdf_id');
    }
}
