<?php

/**
 * Signature CustomerDownload Module
 *
 */

namespace Signature\CustomerDownload\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Filesystem;
use \Magento\Backend\App\Action\Context;

/**
 * Class Upload
 */
class Upload extends \Magento\Backend\App\Action {

    /**
     * Image uploader
     *
     * @var \Magento\Catalog\Model\ImageUploader
     */

    protected $_resultFactory;
    protected $_mediaDirectory;
    protected $_fileUploaderFactory;
    

    /**
     * Upload constructor.
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Catalog\Model\ImageUploader $imageUploader
     */
    public function __construct(
    Context $context,        
    \Magento\Framework\Filesystem $filesystem,
    \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory
) {
    $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
    $this->_fileUploaderFactory = $fileUploaderFactory;
    parent::__construct($context);
}

    /**
     * Check admin permissions for this controller
     *
     * @return boolean
     */
    protected function _isAllowed() {
        return $this->_authorization->isAllowed('Signature_CustomerDownload::helloworld');
    }

    /**
     * Upload file controller action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {
       // $data = $this->getRequest()->getPostValue();
        //try {
//            //$result = $this->imageUploader->saveFileToTmpDir('logo');
//            $targetfolder = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)
//                    ->getAbsolutePath('images/');
//            $baseName = $_FILES['customer_pdf']['name']['logo'];
//            $targetfolder = $targetfolder . $baseName;
//            //$ok = 1;
//            $file_type = $_FILES['customer_pdf']['type']['logo'];
//
//            if ($file_type == "application/pdf") {
//                $fileTempName = $_FILES['customer_pdf']['tmp_name']['logo'];
//
//                if (move_uploaded_file($fileTempName, $targetfolder)) {
//                    echo "The file " . $baseName . " is uploaded";
//                } else {
//                    echo "Problem uploading file";
//                }
//            } else {
//                echo "You may only upload PDFs files.<br>";
//            }
            
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultRedirectFactory->create();
            try {
                $target = $this->_mediaDirectory->getAbsolutePath('images/');
                /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                $uploader = $this->_fileUploaderFactory->create(['fileId' => 'logo']);
                /** Allowed extension types */
                $uploader->setAllowedExtensions(['pdf']);
                /** rename file name if already exists */
                $uploader->setAllowRenameFiles(true);
                /** upload file in folder "mycustomfolder" */
                $result = $uploader->save($target);
                if ($result['logo']) {
                    $this->messageManager->addSuccess(__('File has been successfully uploaded'));
                }
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
            return $this->resultRedirectFactory->create()->setPath('*/*/edit', ['_secure' => $this->getRequest()->isSecure()]
            );
}
}