<?php

/**
 * Signature CustomerDownload Module
 *
 */

namespace Signature\CustomerDownload\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Filesystem\DirectoryList;

/**
 * Class Upload
 */
class Upload extends \Magento\Backend\App\Action {

    /**
     * Image uploader
     *
     * @var \Magento\Catalog\Model\ImageUploader
     */
    protected $imageUploader;
    protected $_fileUploaderFactory;
    protected $_filesystem;
    protected $_resultFactory;
    

    /**
     * Upload constructor.
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Catalog\Model\ImageUploader $imageUploader
     */
    public function __construct(
    \Magento\Backend\App\Action\Context $context, \Signature\CustomerDownload\Model\ImageUploader $imageUploader, \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory, \Magento\Framework\Filesystem $filesystem,
    ResultFactory $resultFactory        
    ) {
        parent::__construct($context);
        $this->imageUploader = $imageUploader;
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->_filesystem = $filesystem;
        $this->_resultFactory = $resultFactory;
    }

    /**
     * Check admin permissions for this controller
     *
     * @return boolean
     */
    protected function _isAllowed() {
        return $this->_authorization->isAllowed('Signature_CustomerDownload::helloworld');
    }

    /**
     * Upload file controller action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {
       // $data = $this->getRequest()->getPostValue();
        try {
            //$result = $this->imageUploader->saveFileToTmpDir('logo');
            $targetfolder = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)
                    ->getAbsolutePath('images/');
            $baseName = $_FILES['customer_pdf']['name']['logo'];
            $targetfolder = $targetfolder . $baseName;
            //$ok = 1;
            $file_type = $_FILES['customer_pdf']['type']['logo'];

            if ($file_type == "application/pdf") {
                $fileTempName = $_FILES['customer_pdf']['tmp_name']['logo'];

                if (move_uploaded_file($fileTempName, $targetfolder)) {
                    echo "The file " . $baseName . " is uploaded";
                } else {
                    echo "Problem uploading file";
                }
            } else {
                echo "You may only upload PDFs files.<br>";
            }
        } catch (\Exception $e) {
            $result = ['error' => $e->getMessage(), 'errorcode' => $e->getCode()];
        }
            $result = array('cookie' => array('name' => $this->_getSession()->getName(),
                                            'value' => $this->_getSession()->getSessionId(),
                                            'lifetime' => $this->_getSession()->getCookieLifetime(),
                                            'path' => $this->_getSession()->getCookiePath(),
                                            'domain' => $this->_getSession()->getCookieDomain()
                                        ));
        return $this->_resultFactory->create(ResultFactory::TYPE_JSON)->setData($result);
    }

}
