<?php
/**
 *  Copyright © 2017 Magento. All rights reserved.
 *  See COPYING.txt for license details.
 */
namespace Signature\CustomerDownload\Controller\Adminhtml\Pdf;
use Magento\Backend\App\Action;
use Signature\CustomerDownload\Model\Downloads;

/**
 * Class Delete
 * @package Signature\CustomerDownload\Controller\Adminhtml\Pdf
 */
class Delete extends Action
{
    /**
     * @var null|Pdf
     */
    protected $pdf = null;
    /**
     * Edit constructor.
     */
    public function __construct(
        Action\Context $context,
        Downloads $pdf
    )
    {
        $this->pdf = $pdf;
        parent::__construct($context);
    }

    /**
     * Save action
     */
    public function execute()
    {
        $entityId = $this->getRequest()->getParam('pdf_id');

        $this->pdf->load($entityId);
        if ($this->pdf->getId()) {
            $this->pdf->delete();
        }
        
        $this->_redirect('downloads/grid/index');
    }
}