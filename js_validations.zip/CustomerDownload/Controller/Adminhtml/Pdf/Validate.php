<?php
/**
 *  Copyright © 2017 Magento. All rights reserved.
 *  See COPYING.txt for license details.
 */

namespace Signature\CustomerDownload\Controller\Adminhtml\Pdf;
use Magento\Backend\App\Action;

/**
 * Class Validate
 * @package Signature\CustomerDownload\Controller\Adminhtml\Pdf
 */
class Validate extends Action
{
    /**
     * Validator
     */
    public function execute()
    {
        $this->getResponse()->appendBody(json_encode(true));
        $this->getResponse()->sendResponse();
    }
}