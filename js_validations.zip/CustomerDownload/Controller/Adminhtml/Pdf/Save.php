<?php
/**
 * Copyright © 2017 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Signature\CustomerDownload\Controller\Adminhtml\Pdf;
use Magento\Backend\App\Action;
use Signature\CustomerDownload\Model\Downloads;

/**
 * Class Save
 * @package Signature\CustomerDownload\Controller\Adminhtml\Ddf
 */
class Save extends Action
{
    /**
     * @var null|Pdf
     */
    protected $pdf = null;

    /**
     * Edit constructor.
     */
    public function __construct(Action\Context $context, Downloads $pdf)
    {
        $this->pdf = $pdf;
        parent::__construct($context);
    }

    /**
     * Save action
     */
    public function execute()
    {
        $postData = $this->getRequest()->getParam('customer_pdf');
        $this->pdf->setData($postData)->save();

        $this->_redirect('downloads/grid/index');
    }
}