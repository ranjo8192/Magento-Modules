<?php
/**
 * Copyright © 2017 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Signature\CustomerDownload\Setup;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema
 * @package Signature\CustomerDownload\Setup
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $tableName = $setup->getTable('customer_downloads');
        $table = $setup->getConnection()->newTable($tableName);
        $table->addColumn(
            'pdf_id',
            \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
            null,
            [
                'identity' => true,
                'nullable' => true,
                'primary' => true,
            ],
            'PDF ID'
        )->addColumn(
            'pdf_name',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            [
                'nullable' => false
            ],
            'PDF Name'
        )->addColumn(
            'pdf_detail',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            255,
            ['nullable' => false],
            'PDF Detail'
        )->setComment('Customer Downloads Pdf Table');

        $setup->getConnection()->createTable($table);
        $setup->endSetup();
    }

}