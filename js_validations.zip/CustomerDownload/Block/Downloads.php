<?php
namespace Signature\CustomerDownload\Block;

use Magento\Framework\View\Element\Template\Context;
use Signature\CustomerDownload\Model\DownloadsFactory;
	/**
	 * Downloads Data View block
	 */
class Downloads extends \Magento\Framework\View\Element\Template
{

    /**
     *@var Magento\Customer\Model\Session
     */
	protected $_customerSession;
	
	/**
     *@var Signature\CustomerDownload\Model\DownloadsFactory;
     */
	protected $_downloads;
	
	/**
     * Create constructor.
     * @param Context $context
     * @param Magento\Customer\Model\Session $customerSession
     * @param DownloadsFactory $downloads
     */
    public function __construct(
        Context $context,
		\Magento\Customer\Model\Session $customerSession,
		DownloadsFactory $downloads
    ) {
        parent::__construct($context);
		$this->_customerSession = $customerSession;
		$this->_downloads = $downloads;
    }
	
	public function getConfigDownloads()
	{
		$collection = $this->_downloads->create()->getCollection()
												 ->addFieldToSelect('*');
												  //->addFieldToFilter('*');
		
		return $collection;
	}
	
}