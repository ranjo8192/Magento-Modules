<?php
/**
 * Copyright � 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Signature\Customers\Controller\Adminhtml\Index;
 
class CustomerConfigurationPost extends \Magento\Backend\App\Action
{
   
    public function execute()
    {
		echo "<pre>";
		$this->getRequest()->getPost();
		die("Hello this is hitting controller");
		
        $this->initCurrentCustomer();
        $resultLayout = $this->resultLayoutFactory->create();
        return $resultLayout;
    }
 
 
}