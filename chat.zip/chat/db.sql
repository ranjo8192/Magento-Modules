-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2018 at 09:38 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data1`
--

-- --------------------------------------------------------

--
-- Table structure for table `pm`
--

CREATE TABLE `pm` (
  `id` bigint(20) NOT NULL,
  `id2` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `user1` bigint(20) NOT NULL,
  `user2` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `timestamp` int(10) NOT NULL,
  `user1read` varchar(3) NOT NULL,
  `user2read` varchar(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pm`
--

INSERT INTO `pm` (`id`, `id2`, `title`, `user1`, `user2`, `message`, `timestamp`, `user1read`, `user2read`) VALUES
(1, 1, 'abs', 2, 1, 'efghgf', 1537611448, 'yes', 'no'),
(2, 1, 'abser', 2, 1, 'fgfgfg', 1537611493, 'yes', 'yes'),
(2, 2, '', 1, 0, 'sdsdds', 1537611777, '', ''),
(2, 3, '', 1, 0, 'eewrrrr', 1537611883, '', ''),
(2, 4, '', 1, 0, 'errtte', 1537611951, '', ''),
(6, 1, 'abstttt', 2, 1, 'ttteeeeeeef', 1537611973, 'yes', 'no'),
(2, 5, '', 2, 0, 'trrefrtertre', 1537611985, '', ''),
(2, 6, '', 1, 0, 'rerre', 1537612003, '', ''),
(2, 7, '', 2, 0, 'err', 1537612014, '', ''),
(10, 1, 'abc', 3, 2, 'hello nitin', 1537800880, 'yes', 'yes'),
(11, 1, 'abc', 2, 3, 'sdfghgfd', 1537800943, 'yes', 'yes'),
(10, 2, '', 2, 0, 'ddkjdkdh,', 1537801038, '', ''),
(11, 2, '', 3, 0, 'dfshfhsj', 1537801066, '', ''),
(11, 3, '', 3, 0, 'djfdjdfk<br />\r\n', 1537801177, '', ''),
(15, 1, 'f', 2, 3, 'dfgh', 1537801341, 'yes', 'no'),
(16, 1, 'abcwsww', 2, 3, 'sdffdff', 1537801682, 'yes', 'no'),
(11, 4, '', 3, 0, 'cdcjkdfdk', 1537801702, '', ''),
(18, 1, 'abc', 2, 3, 'dnjddbjdsbjs', 1537889733, 'yes', 'yes'),
(18, 2, '', 2, 0, 'dnjdfjfh', 1537889809, '', ''),
(18, 3, '', 3, 0, 'bjfdsjjsd', 1537889958, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `avatar` text NOT NULL,
  `signup_date` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `avatar`, `signup_date`) VALUES
(1, 'jhggf4', '123456', 'dwiveedink07@gmail.com', '', 1537564487),
(2, 'nitin', '123456', 'ni3dwivedi@gmail.com', '', 1537611047),
(3, 'saurabh', 'abc123', 'kushwaha.ranjeet8192@gmail.com', '', 1537800800);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
