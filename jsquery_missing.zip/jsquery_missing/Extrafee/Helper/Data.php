<?php

namespace Signature\Extrafee\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    /**
     * Custom fee config path
     */
    const CONFIG_CUSTOM_FEE_LABEL = 'process/fee/fee_label';
    const CONFIG_CUSTOM_PROCESS_FEE = 'process/fee/process_fee';
    const CONFIG_CUSTOM_START_TIME = 'process/fee/start_time';
    const CONFIG_CUSTOM_END_TIME = 'process/fee/end_time';
    const CONFIG_CUSTOM_CLOSED_TIME = 'process/fee/closed_time';
    
    /**
     * @return mixed
     */
    public function isModuleEnabled()
    {
        return true;
    }

    /**
     * Get custom fee label
     *
     * @return mixed
     */
    public function getFeeLabel()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $feeLabel = $this->scopeConfig->getValue(self::CONFIG_CUSTOM_FEE_LABEL, $storeScope);
        return $feeLabel;
    }
    
    /**
     * Get custom fee
     *
     * @return mixed
     */
    public function getProcessFee()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $fee = $this->scopeConfig->getValue(self::CONFIG_CUSTOM_PROCESS_FEE, $storeScope);
        return $fee;
    }
    
    /**
     * Get Start Time
     *
     * @return startTime
     */
    public function getStartTime()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $startTime = $this->scopeConfig->getValue(self::CONFIG_CUSTOM_START_TIME, $storeScope);
        return $startTime;
    }

    /**
     * Get End Time
     *
     * @return endTime
     */
    public function getEndTime()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $endTime = $this->scopeConfig->getValue(self::CONFIG_CUSTOM_END_TIME, $storeScope);
        return $endTime;
    }
    
    /**
     * Get Closed Time
     *
     * @return closedTime
     */
    public function getClosedTime()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $closedTime = $this->scopeConfig->getValue(self::CONFIG_CUSTOM_CLOSED_TIME, $storeScope);
        return $closedTime;
    }
}
