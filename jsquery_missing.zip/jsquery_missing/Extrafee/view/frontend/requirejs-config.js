var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Signature_Extrafee/js/model/shipping-save-processor/default'
        }
    }
};
