<?php

namespace Package\Module\Setup;
 
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
 
class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        $connection = $installer->getConnection();
 
        if ($connection->tableColumnExists('sales_order', 'my_new_column') === false) {
            $connection
                ->addColumn(
                    $setup->getTable('sales_order'),
                    'my_new_column',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'length' => 0,
                        'comment' => 'My New Order Column'
                    ]
                );
        }
        $installer->endSetup();
    }
}