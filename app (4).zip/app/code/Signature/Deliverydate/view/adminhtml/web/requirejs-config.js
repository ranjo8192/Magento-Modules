var config = {
    "map": {
        "*": {
            "Oye_Deliverydate/js/date_preview" : "Oye_Deliverydate/js/date_preview"
        }
    }
};