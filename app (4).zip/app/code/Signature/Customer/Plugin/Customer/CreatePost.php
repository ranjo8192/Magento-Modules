<?php
namespace Signature\Customer\Plugin\Customer;
use Magento\Customer\Model\AddressFactory;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\App\Action\Context;
use Magento\Customer\Api\CustomerRepositoryInterface;

class CreatePost
{	
    /**
	 * @var \Magento\Customer\Api\CustomerRepositoryInterface
	 */
	private $customerRepository;
	/**
	 * @var \Magento\Customer\Model\AddressFactory
	 */
	protected $addressFactory;
	
	/**
	 * @var \Magento\Customer\Model\CustomerFactory
	 */
	protected $customerFactory;
	/**
     * CreatePost constructor.
     * @param Context $context
     * @param AddressFactory $addressFactory
     * @param CustomerFactory $customerFactory
     * @param CustomerRepositoryInterface $customerRepository
     */
    public function __construct(
		 Context $context,
		 AddressFactory $addressFactory,
		 CustomerFactory $customerFactory,
		 CustomerRepositoryInterface $customerRepository
    ) {
        $this->_request = $context->getRequest();
        $this->_response = $context->getResponse();
        $this->resultRedirectFactory = $context->getResultRedirectFactory();
        $this->resultFactory = $context->getResultFactory();
		$this->addressFactory = $addressFactory;
		$this->customerFactory = $customerFactory;
		 $this->customerRepository = $customerRepository;

    }

    public function afterExecute(\Magento\Customer\Controller\Account\CreatePost $subject, $proceed)
    {    
	
		$post = $this->_request->getPostValue();
		$customerData = $this->customerFactory->create();
		$customerObj  =	$customerData->getCollection()
						->addAttributeToSelect('entity_id')
						->addAttributeToSort('entity_id','desc');
		
		if($customerObj->getSize()){					
			$data = $customerObj->getFirstItem();
			$customerId =  $data->getId();
			$customer = $this->customerRepository->getById($customerId); 
			switch($post['profile_group'])
			{
				case 1:
				$group_id = 4;
				break;
				
				case 2:
				$group_id = 5;
				break;
				
				case 3:
				$group_id = 6;
				break;

			}		
			$customer->setGroupId($group_id);    
			$this->customerRepository->save($customer);
			if(empty($post['sameShipping']) && $group_id != 5){
				$address = $this->addressFactory->create();
				$address->setCustomerId($customerId)
						->setParentId($customerId)
						->setFirstname($post['firstname'])			 
						->setLastname($post['lastname'])	
						->setRegionId($post['bregion_id'])
						->setRegion($post['bregion'])						
						->setCountryId($post['bcountry_id'])			 
						->setPostcode($post['bpostcode'])			 
						->setCity($post['bcity'])			 
						->setTelephone($post['telephone'])			 		 	 
						->setStreet($post['bstreet'][0]." ".$post['bstreet'][1])			 
						->setIsDefaultBilling('1')			 
						->setIsDefaultShipping('0')			 
						->setSaveInAddressBook('1');
				$address->save();
			}
		}
		return $proceed;
    }
}