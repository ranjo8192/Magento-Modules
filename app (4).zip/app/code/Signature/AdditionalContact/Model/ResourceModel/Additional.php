<?php
namespace Signature\AdditionalContact\Model\ResourceModel;
class Additional extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('additional_contact', 'additional_id');   //here "additional_contact" is table name and "additional_id" is the primary key of custom table
    }
}