<?php
 
namespace Signature\AdditionalContact\Block;
 
use Magento\Framework\View\Element\Template\Context;
use Signature\AdditionalContact\Model\AdditionalFactory;
/**
 * Additional Data View block
 */
class Additional extends \Magento\Framework\View\Element\Template
{
    /**
     *@var Signature\AdditionalContact\Model\AdditionalFactory
     */
    protected $_additional;

    /**
     *@var Magento\Customer\Model\Session
     */
	protected $_customerSession;
	
    public function __construct(
        Context $context,
        AdditionalFactory $additional,
		\Magento\Customer\Model\Session $customerSession
    ) {
        $this->_additional = $additional;
        parent::__construct($context);
		$this->_customerSession = $customerSession;
    }
 
    public function getAdditionalData()	
    {
		$customerID =  $this->_customerSession->getCustomer()->getId();
		$collection = $this->_additional->create()->getCollection()
												  ->addFieldToSelect('*')
												  ->addFieldToFilter('customer_id', array('eq' => $customerID));
												
        return $collection;
        
    }
}