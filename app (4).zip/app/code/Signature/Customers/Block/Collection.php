<?php
namespace Signature\Customers\Block;
  
class Collection extends \Magento\Framework\View\Element\Template
{
	/**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
	protected $_productCollectionFactory;
	
	public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
		\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
		array $data = []
    )
    {
		$this->_productCollectionFactory = $productCollectionFactory;
        parent::__construct($context);
    }
	
	/**
	 * Product Collection
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
	
    public function getProductCollection()
    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*')->load();
        return $collection;
    }
}