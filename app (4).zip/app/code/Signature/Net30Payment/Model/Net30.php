<?php
namespace Signature\Net30Payment\Model;

class Net30 extends \Magento\Payment\Model\Method\AbstractMethod
{
	const PAYMENT_METHOD_CUSTOM_INVOICE_CODE = 'net30';
	/**
	* Payment method code
	*
	* @var string
	*/
	protected $_code = self::PAYMENT_METHOD_CUSTOM_INVOICE_CODE;
	
	/**
     * Get instructions text from config
     *
     * @return string
     */
    public function getInstructions($_code)
    {
        return trim($this->getConfigData('instructions'));
    }
	

}