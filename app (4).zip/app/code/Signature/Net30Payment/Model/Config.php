<?php

namespace Signature\Net30Payment\Model;

class Config 
{
   /**
   * @var \Magento\Framework\App\Config\ScopeConfigInterface
   */
   protected $scopeConfig;

   public function __construct(\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig)
   {
      $this->scopeConfig = $scopeConfig;
   }

   /**
   * Sample function returning config value
   **/

  public function getInstructions() {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        return $this->scopeConfig->getValue("payment/net30/instructions", $storeScope);
    }
}