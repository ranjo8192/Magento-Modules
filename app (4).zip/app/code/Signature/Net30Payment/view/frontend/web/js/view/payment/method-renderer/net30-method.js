define(
        [
            'ko',
            'Magento_Checkout/js/view/payment/default',
            'jquery'
        ],
        function (ko, Component,$) {
            'use strict';
            return Component.extend({
                defaults: {
                    template: 'Signature_Net30Payment/payment/net30'
                },
                /** Returns send check to info */
                getMailingAddress: function () {
                    return window.checkoutConfig.payment.net30.mailingAddress;
                },
                /** Returns payable to info */
                
                 /**
                 * Get value of instruction field.
                 * @returns {String}
                 */
                getInstructions: function () {
                    return window.checkoutConfig.payment.net30.instruction;
                }
            });
        }
);