<?php
namespace Signature\CustomerOrder\Block;
use Magento\Framework\View\Element\Template\Context;
use Magento\Catalog\Model\ProductRepository;
use Signature\CustomerOrder\Model\ConfigCollection;

class NewOrder extends \Magento\Framework\View\Element\Template
{ 
	 
	 /**
     * @var Magento\Catalog\Model\ProductRepository
     */
	 protected $_productRepository;
	 
	 /**
     * @var Signature\CustomerOrder\Model\ConfigCollection
     */
	 protected $_configCollection;
	 

	
	public function __construct(
		Context $context,
		ProductRepository $productRepository,
		ConfigCollection $configCollection,
		array $data = []
	) {
		$this->_productRepository = $productRepository;
		$this->_configCollection = $configCollection;
		parent::__construct($context, $data);
	}
	
	
	/**
     * Get Product Collection by ID 
     */
	
	public function getProductById($id = null)
	{
		return $this->_productRepository->getById($id);
	}
	
	/**
     * Get customer data by session 
     */
	public function getCustomerSession(){
		
        return $this->_configCollection->getCustomerSession();
     }
	 
	 /**
     * Get Product Config Collection from custom Table 
     *
     * @return Product Config Collection form customer_configuration.
     */
	 
	public function getCustomerConfigCollection()
    {
        return $this->_configCollection->getCustomerConfigCollection();
    }
	
	/**
     * Get Product Collection 
     *
     * @return Product Collection filtered by config product Id
     */
	
	public function getProductCollection()
	{
		return $this->_configCollection->getProductCollection();
	}
	
	/**
     * Get Product Cart Information
     *
     * @return cart Item
     */
	
	public function getItemsQty()
	{
		return $this->_configCollection->getItemsQtyCart();
	}
}