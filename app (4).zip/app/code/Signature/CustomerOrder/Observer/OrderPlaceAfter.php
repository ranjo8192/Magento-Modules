<?php
namespace Signature\CustomerOrder\Observer;

use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Signature\Customers\Model\AdditionalFactory;


class OrderPlaceAfter implements ObserverInterface
{
		protected $_loggers;
		
		protected $orderRepository;
		/**
		 * Order Model
		 *
		 * @var \Magento\Sales\Model\Order $order
		 */
		protected $_order;
		/**
		 * Config Model
		 *
		 * @var Signature\CustomerOrder\Model\ConfigCollection $_configCollection
		 */
		protected $_configCollection;
		
		/**
		 * @var Signature\Customers\Model\Additional
		 */
		 protected $_additional;
		
		public function __construct
		(
		LoggerInterface $loggers,
		OrderRepositoryInterface $OrderRepositoryInterface,
		\Magento\Sales\Model\Order $order,
		AdditionalFactory $additional
		)
		{
		$this->_loggers = $loggers;
		$this->orderRepository = $OrderRepositoryInterface;
		$this->_order = $order;
		$this->_additional = $additional;
		}
		
		public function execute(\Magento\Framework\Event\Observer $observer)
			{
			   $orderId = $observer->getEvent()->getOrderIds();
				$order = $this->_order->load($orderId);
				$customerId = $order->getCustomerId(); // using this id you can get customer name

				//get Order All Item
				$orderItems = $order->getAllItems();
				$data = array();
				foreach($orderItems as $item){
					$itemQty = $item->getQtyOrdered();
					$itemId = $item->getProductId();
					$data[$itemId] = $itemQty;
				}
			
				$this->getCustomerConfigCollection($data, $customerId);
				

			}
			
		public function getCustomerConfigCollection($orderedItem = null, $customerId = null)
			{
				$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
				$logger = new \Zend\Log\Logger();
				$logger->addWriter($writer);
				
				$configCollection = $this->_additional->create()->load($customerId,'customer_id');
																//->addFieldToSelect(['product_information','customer_id'])
																//->addFieldToFilter('customer_id',$customerId);
				
				
				foreach($orderedItem as $key => $item){
					$configProInfo  = $configCollection->getProductInformation();
					$data = json_decode($configProInfo,true);
					$data["product_qty"][$key] = $data["product_qty"][$key]-$item;
					$data = json_encode($data);
					$configCollection->setProductInformation($data);
					$configCollection->save();
					}
					
				
				//$configItems = $configProInfo[0]['product_information'];
				
				$logger->info(print_r($orderedItem,true));												
				$logger->info($configCollection->getData('product_information'));												
				$logger->info($data);												
				
				return $configCollection;
			}	
}