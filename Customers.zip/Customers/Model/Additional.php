<?php
namespace Signature\Customers\Model;
use Magento\Framework\Model\AbstractModel;
class Additional extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('Signature\Customers\Model\ResourceModel\Additional');
    }
}