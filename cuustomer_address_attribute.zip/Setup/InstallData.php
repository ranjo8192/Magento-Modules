<?php
/**
 * Webkul Software.
 *
 * @category  Vendor
 * @package   Vendor_Module
 * @author    Vendor
 * @copyright Copyright (c) 2010-2018 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Signature\SalesRep\Setup;


use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Customer\Model\Customer;
use Magento\Eav\Model\Entity\Attribute\Set as AttributeSet;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface {
protected $customerSetupFactory;
private $attributeSetFactory;

public function __construct(CustomerSetupFactory $customerSetupFactory, AttributeSetFactory $attributeSetFactory) {
    $this->customerSetupFactory = $customerSetupFactory;
    $this->attributeSetFactory = $attributeSetFactory;
}

public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context) {

    $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);

    $customerEntity = $customerSetup->getEavConfig()->getEntityType('customer_address');
    $attributeSetId = $customerEntity->getDefaultAttributeSetId();

    $attributeSet = $this->attributeSetFactory->create();
    $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);

    $customerSetup->addAttribute('customer_address', 'approve_address', [
        'type' => 'text',
        'label' => 'Approve Address',
        'input' => 'select',
        'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
        'required' => false,
        'visible' => true,
        'user_defined' => true,
        'sort_order' => 500,
        'position' => 101,
        'system' => 0,
        'option' =>
            array (
                'values' =>
                    array (
                        0 => 'No',
                        1 => 'Yes'
                    ),
            ),
    ]);

    $attribute = $customerSetup->getEavConfig()->getAttribute('customer_address', 'approve_address')
        ->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId,
            'used_in_forms' => ['adminhtml_customer_address','customer_address_edit','customer_register_address'],
        ]);

    $attribute->save();

    }
}