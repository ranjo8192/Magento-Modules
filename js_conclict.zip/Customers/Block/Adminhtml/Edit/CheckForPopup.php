<?php
namespace Signature\Customers\Block\Adminhtml\Edit;
use Magento\Customer\Controller\RegistryConstants;
use Magento\Ui\Component\Layout\Tabs\TabInterface;
use Signature\Customers\Model\AdditionalFactory;
use Magento\CatalogInventory\Model\Stock\StockItemRepository;
 
class CheckForPopup extends \Magento\Backend\Block\Template implements TabInterface
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;
    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
	 protected $_additional;
	 
	 /**
     * product StockItem
     *
     * @var Magento\CatalogInventory\Api\StockStateInterface
     */
	 protected $_stockItem;
 
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
		AdditionalFactory $additional,
		StockItemRepository $stockItem,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        $this->collection = $collection;
		$this->_additional = $additional;
		$this->_stockItem = $stockItem;
        parent::__construct($context, $data);
    }
 
    /**
     * @return string|null
     */
    public function getCustomerId()
    {
        return $this->_coreRegistry->registry(RegistryConstants::CURRENT_CUSTOMER_ID);
    }
	/**
     * Get Product Collection
     *
     * @return Collection
     */
    public function getCustomerConfigCollection()
    {
		$customerId = $this->_coreRegistry->registry(RegistryConstants::CURRENT_CUSTOMER_ID);
		$configCollection = $this->_additional->create()->getCollection()
														->addFieldToSelect('*')
														->addFieldToFilter('customer_id', array('eq' => $customerId));
		$configCollection = json_decode($configCollection->getData());
        return $configCollection;
    }
	/**
     * Get Product Stock Information
     *
     * @return Stco Information
     */
    public function getQty($id = null)
    {
        return $this->_stockItem->get($id)->getQty();
    }
	

}