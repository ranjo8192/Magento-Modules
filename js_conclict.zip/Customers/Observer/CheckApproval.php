<?php

namespace Signature\Customers\Observer;


use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Registry;
use Magento\Framework\App\RequestInterface;
use Signature\Customers\Helper\Email;
use Magento\Framework\Mail\Template\TransportBuilder;

class CheckApproval implements ObserverInterface
{
	
	private $helperEmail;
	
    protected $coreRegistry;
	/**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $_request;
    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    public function __construct(
		Registry $registry,
		Email $helperEmail,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Store\Model\StoreManagerInterface $storeManager
		)
		{
			$this->coreRegistry = $registry;
			$this->_request = $request;
			$this->_storeManager = $storeManager;
			$this->helperEmail = $helperEmail;
			//parent::__construct($context);
		}

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		$event = $observer->getEvent();
		$customer = $event->getCustomer();
		$name = $customer->getFirstName();
		$email = $customer->getEmail();
		$id = $customer->getId();
		
		return $this->helperEmail->sendEmail($customer);
		
	}
}