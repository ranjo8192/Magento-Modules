<?php

namespace Signature\Deliverydate\Helper;


/**
 * Class Data
 * @package Signature\Deliverydate\Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    public $timeZone;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    public $storeManager;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timeZone
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timeZone,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    )
    {
        $this->timeZone = $timeZone;
        $this->storeManager = $storeManager;
        return parent::__construct($context);
    }

    /**
     * take mysql datetime string and convert it to given format
     *
     * @param $dateString
     * @param string|false $format
     * @param \Magento\Store\Model\Store|false $store
     * @return string
     */
    public function formatMySqlDateTime($dateString, $format = false, $store = false)
    {
        if($dateString == '0000-00-00 00:00:00')
        {
            $result = 'N/A';
            return $result;
        }
        $format = $format ? $format : $this->getConfigDateFormat();
        $store = $store ? $store : $this->storeManager->getStore();
        return $this->timeZone
            ->scopeDate($store, $dateString, true)
            ->format($format);
    }

    /**
     * @return bool
     */
    public function isRequestAdmin()
    {
        return strpos($this->_request->getPathInfo(), 'admin') === false;
    }

    /**
     * @return mixed
     */
    public function getConfigDateFormat()
    {
        $dateFormat = 'Y-m-d';
        return $dateFormat;
    }

    /**
     * @return string
     */
    public function getConfigFieldLabel()
    {
        return 'Delivery Date';
    }
}