var config = {
    "map": {
        "*": {
            "Magento_Checkout/js/model/shipping-save-processor/default" : "Signature_Deliverydate/js/shipping-save-processor-default-override"
        }
    }
};