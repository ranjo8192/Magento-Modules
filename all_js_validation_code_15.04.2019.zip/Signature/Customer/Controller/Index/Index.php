<?php
namespace Signature\Customer\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\View\Result\PageFactory;

class Index extends Action {
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    private $pageFactory;


    /**
     * Index constructor.
     * @param Context $context
     * @param PageFactory $pageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $pageFactory
    )
    {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
		$this->request = $context->getRequest();
    }
	
	/**
     * Get request post value "API Number"
     *
     * @var call the function makeApiCall()
     */
    public function execute()
    {
		$post = $this->request->getPostValue();
		$response_result=$this->makeApiCall($post['npi_number']);
		echo $response_result;die;
    }
	
	/**
     * @var Call Api with curl
     * @var Return the result
     */
	private function makeApiCall($npiNumber)
	{
		$apiUrl='https://www.hipaaspace.com/api/npi/check_status?q='.$npiNumber.'&rt=json&token=3932f3b0-cfab-11dc-95ff-0800200c9a663932f3b0-cfab-11dc-95ff-0800200c9a66';
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_URL,$apiUrl);
		$result=curl_exec($ch);
		curl_close($ch);
		return $result;
	}
}
?>