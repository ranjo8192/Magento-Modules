require([
    'jquery'
], function ($) {
    'use strict';
		$(document).on('click','#tab_customer',function(){
			if($('select[name="customer[group_id]"] option:selected').val() == undefined )
			{
				setTimeout(function(){
				   $('#tab_customer').trigger('click');
				}, 3000);
			}else{
				var group_id = $('select[name="customer[group_id]"] option:selected').val();
				if(group_id == "5" || group_id == "6"){
					$('#tab_block_customer_edit_tab_customer_configuration').hide();
					$('[data-index="rep_name"], [data-index="rep_name"]').hide(); 
					$('[data-index="doctor_npi"], [data-index="doctor_npi"]').hide();
					$('[data-index="npi_status"], [data-index="npi_status"]').hide();
				}
				else if(group_id == '4'){
					$('[data-index="taxvat"], [data-index="taxvat"]').hide();
					$('[data-index="npi_status"], [data-index="npi_status"]').hide();
				}	
			}
		});
		
		// Customer group On change 
		$(document).on('change','select[name="customer[group_id]"]',function(){
			var groupid = $(this).val();
			if(groupid == "5" || groupid == "6"){
				$('#tab_block_customer_edit_tab_customer_configuration').hide();
				$('[data-index="taxvat"], [data-index="taxvat"]').show();
				$('[data-index="npi_status"], [data-index="npi_status"]').show();
				$('[data-index="rep_name"], [data-index="rep_name"]').hide(); 
				$('[data-index="doctor_npi"], [data-index="doctor_npi"]').hide();
				$('[data-index="npi_status"], [data-index="npi_status"]').hide();
			}
			else if(groupid == '4'){
				$('[data-index="rep_name"], [data-index="rep_name"]').show(); 
				$('[data-index="doctor_npi"], [data-index="doctor_npi"]').show();
				$('[data-index="npi_status"], [data-index="npi_status"]').show();
				$('[data-index="taxvat"], [data-index="taxvat"]').hide();
				$('[data-index="npi_status"], [data-index="npi_status"]').hide();
				$('#tab_block_customer_edit_tab_customer_configuration').show();
			}  
		});
	});

