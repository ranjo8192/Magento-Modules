<?php

namespace Signature\Net30Payment\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Signature\Net30Payment\Model\Config;


class Net30ConfigProvider implements ConfigProviderInterface
{
	const CODE = 'net30';
    
    private $config;

    /**
     * @param Config $config
     */
    public function __construct(Config $config) {
        $this->config = $config;
    }

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array instaruction config
     */

    public function getConfig()
    {
        return [
            'payment' => [
                self::CODE => [
                    'instruction' => $this->config->getInstructions()
                ]
            ]
        ];
    }
}
