<?php
namespace Signature\CustomerOrder\Model;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\ObjectManagerInterface;
use Signature\Customers\Model\AdditionalFactory;
use Magento\Catalog\Model\ProductRepository;
use Magento\CatalogInventory\Model\Stock\StockItemRepository;
use Magento\Checkout\Model\Cart;

class ConfigCollection
{
	/**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
	protected $_productCollectionFactory;
	
	/**
	 * @var \Magento\Framework\ObjectManagerInterface
	 */
	protected $_object;
	
	/**
     * @var Signature\Customers\Model\Additional
     */
	 protected $_additional;
	 
	 /**
     * @var Magento\Catalog\Model\ProductRepository
     */
	 protected $_productRepository;
	 
	/**
     * product StockItem
     *
     * @var Magento\CatalogInventory\Api\StockStateInterface
     */
	 protected $_stockItem;
	 
	 /**
     * Cart Item
     *
     * @var Magento\Checkout\Model\Cart
     */
	 protected $_cart;
	
	/**
     * Create constructor.
     * @param CollectionFactory $productCollectionFactory
     * @param ObjectManagerInterface $interface
     * @param AdditionalFactory $additional
     * @param ProductRepository $productRepository
     * @param StockItemRepository $stockItem
     * @param Cart $cart
     */
	public function __construct(
		CollectionFactory $productCollectionFactory,
		ObjectManagerInterface $interface,
		AdditionalFactory $additional,
		ProductRepository $productRepository,
		StockItemRepository $stockItem,
		Cart $cart
	) {
		$this->_productCollectionFactory = $productCollectionFactory; 
        $this->_object = $interface;
		$this->_additional = $additional;
		$this->_productRepository = $productRepository;
		$this->_stockItem = $stockItem;
		$this->_cart = $cart;
	}

	/**
     * Get Product Config Collection from custom Table 
     *
     * @return Product Config Collection form customer_configuration.
     */

    public function getCustomerConfigCollection()
    {
		$customerData = $this->getCustomerSession();
		$customerId = $customerData->getId();
		$configCollection = $this->_additional->create()->getCollection()
														->addFieldToSelect('*')
														->addFieldToFilter('customer_id',$customerId);
        return $configCollection;
    }
	
	/**
     * Get Product Collection 
     *
     * @return Product Collection filtered by config product Id
     */
		
	public function getProductCollection()
	{
		$_configCollection = $this->getCustomerConfigCollection();
		$data = $_configCollection->getData();
		$allProductData = json_decode($data[0]['product_information'], true);
		$collection = $this->_productCollectionFactory->create();
		$collection->addAttributeToSelect('*')
				   ->addAttributeToFilter('entity_id', array('in' => $allProductData['product_id']))
				   ->load();
		return $collection;
	}
	
	/**
     * Get Customer data
     *
     * @return customer data from session
     */
	
	public function getCustomerSession(){
        $customerSession = $this->_object->create('Magento\Customer\Model\Session');
		if($customerSession->isLoggedIn()){
		    return $customerSession->getCustomerData();
		}    
    }
	
	/**
     * Get Product Stock Information
     *
     * @return Stco Information
     */
    public function getQty($id = null)
    {
        return $this->_stockItem->get($id)->getQty();
    }
	
	/**
     * Get Product Cart Information
     *
     * @return cart Item
     */
    public function getItemsQtyCart()
    {
		$totalItems = $this->_cart->getQuote()->getItemsCount();
		$totalQuantity = $this->_cart->getQuote()->getItemsQty();
		if($totalQuantity){
		return number_format($totalQuantity,0);
		}
		return true;
    }
	
}
?>