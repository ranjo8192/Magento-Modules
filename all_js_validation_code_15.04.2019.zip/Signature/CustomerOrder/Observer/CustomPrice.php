<?php
/**
 * Signature\CustomerOrder\Observer
 */
namespace Signature\CustomerOrder\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Checkout\Model\Cart;

class CustomPrice implements ObserverInterface
    {	
		/**
		 *@var Magento\Framework\App\RequestInterface;
		 */
		protected $_request;
		
		/**
		 *@var Magento\Checkout\Model\Cart;
		 */
		protected $_cart;
		
		/**
		 * CreatePost constructor.
		 * @param RequestInterface $request
		 * @param Cart $cart
		 */
		public function __construct(
			RequestInterface $request,
			Cart $cart

		) { 
			$this->_request = $request;
			$this->_cart = $cart;
		}
		
		/**
		 * @var set custom price for the product after add to cart
		 *
		 * @return void
		 */
        public function execute(\Magento\Framework\Event\Observer $observer) {
			
			$post = $this->_request->getPost();
			try{
				if(!empty($post['product_check']))
				{	
						$items = $this->_cart->getQuote()->getAllItems();
						foreach($items as $item) {
							if(in_array($item->getProductId(),$post['product_check'])){
								$item->setCustomPrice($post['productprice'][$item->getProductId()]);
								$item->setOriginalCustomPrice($post['productprice'][$item->getProductId()]);
								$item->getProduct()->setIsSuperMode(true);	
							}							
						  }
				}
			}catch(Exception $e) {
				$logger->info($e->getMessage());
					
				}
		}
}
