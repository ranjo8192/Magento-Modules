<?php
namespace Signature\CustomerOrder\Observer;

use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Signature\Customers\Model\AdditionalFactory;


class OrderPlaceAfter implements ObserverInterface
{
		protected $_loggers;
		
		protected $orderRepository;
		/**
		 * Order Model
		 *
		 * @var \Magento\Sales\Model\Order $order
		 */
		protected $_order;
		/**
		 * Config Model
		 *
		 * @var Signature\CustomerOrder\Model\ConfigCollection $_configCollection
		 */
		protected $_configCollection;
		
		/**
		 * @var Signature\Customers\Model\Additional
		 */
		 protected $_additional;
		
		public function __construct
		(
		LoggerInterface $loggers,
		OrderRepositoryInterface $OrderRepositoryInterface,
		\Magento\Sales\Model\Order $order,
		AdditionalFactory $additional
		)
		{
		$this->_loggers = $loggers;
		$this->orderRepository = $OrderRepositoryInterface;
		$this->_order = $order;
		$this->_additional = $additional;
		}
		
		
		/**
		 * @var get order details by observer 
		 *
		 * @call function getCustomerConfigCollection($data, $customerId)
		 */
		public function execute(\Magento\Framework\Event\Observer $observer)
			{
			   $orderId = $observer->getEvent()->getOrderIds();
				$order = $this->_order->load($orderId);
				$customerId = $order->getCustomerId(); // using this id you can get customer name

				//get Order All Item
				$orderItems = $order->getAllItems();
				$data = array();
				foreach($orderItems as $item){
					$itemQty = $item->getQtyOrdered();
					$itemId = $item->getProductId();
					$data[$itemId] = $itemQty;
				}
			
				$this->getCustomerConfigCollection($data, $customerId);
				

			}
			
			/**
			 * @var get Customer congif details by customer ID
			 *
			 * @ Set customer_config table after placing order
			 * @ return $configCollection
			 */
		public function getCustomerConfigCollection($orderedItem = null, $customerId = null)
			{
				
				$configCollection = $this->_additional->create()->load($customerId,'customer_id');

				foreach($orderedItem as $key => $item){
					$configProInfo  = $configCollection->getProductInformation();
					$data = json_decode($configProInfo,true);
					$data["product_qty"][$key] = $data["product_qty"][$key]-$item;
					$data = json_encode($data);
					$configCollection->setProductInformation($data);
					$configCollection->save();
					}											
				
				return $configCollection;
			}	
}