<?php
namespace Signature\Customers\Controller\Index;
 
class Success extends \Magento\Framework\App\Action\Action
{
	/**
     *@var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	
	/**
     * CreatePost constructor.
     * @param Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct
	(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
	)
    {
        $this->resultPageFactory = $resultPageFactory;       
        return parent::__construct($context);
    }
     
	 /**
     *
     * @return $this->resultPageFactory->create();
     */
    public function execute()
    {
        return $this->resultPageFactory->create(); 
    } 
}