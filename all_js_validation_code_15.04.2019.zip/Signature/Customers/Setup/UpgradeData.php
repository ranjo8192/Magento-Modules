<?php

namespace Signature\Customers\Setup;

use Magento\Eav\Setup\EavSetupFactory;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

use Magento\Eav\Model\Config;

class UpgradeData implements UpgradeDataInterface
{
	/**
     * attribute to identify customer account is approved or not
     */
    const APPROVE_ACCOUNT = 'approve_account';
	/**
	 * @var \Magento\Eav\Setup\EavSetupFactory
	 */
	 
    private $eavSetupFactory;
	
	/**
	 * @var \Magento\Eav\Model\Config
	 */
	 
    private $eavConfig;
	
	/**
	 * @var \Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory
	 */
    private $attributeSetFactory;

    public function __construct(EavSetupFactory $eavSetupFactory, Config $eavConfig, AttributeSetFactory $attributeSetFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->eavConfig       = $eavConfig;
        $this->attributeSetFactory       = $attributeSetFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
	    
	   /**
		* @custom field Rep Name 
		*/
       if (version_compare($context->getVersion(), '2.0.2') < 0) {

            $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
            $customerEntity = $this->eavConfig->getEntityType('customer');
            $attributeSetId = $customerEntity->getDefaultAttributeSetId();
            $attributeSet = $this->attributeSetFactory->create();
            $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);
             
            $eavSetup->updateAttribute(\Magento\Customer\Model\Customer::ENTITY, self::APPROVE_ACCOUNT,
            [
                'is_used_in_grid' => true,
                'is_visible_in_grid' => true,
				'is_filterable_in_grid' => true,
				'is_searchable_in_grid' => true,
            ]);
             
            $attribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, self::APPROVE_ACCOUNT)
            ->addData([
                'attribute_set_id' => $attributeSetId,
                'attribute_group_id' => $attributeGroupId,
                'used_in_forms' => ['adminhtml_customer','customer_account_create','customer_account_edit'],
            ]);
             
            $attribute->save();
        }
    }
}