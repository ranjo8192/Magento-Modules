<?php
namespace Signature\Customers\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Registry;
use Magento\Framework\App\RequestInterface;
use Signature\Customers\Helper\Email;
use Magento\Framework\Mail\Template\TransportBuilder;
use Signature\Customers\Model\AdditionalFactory;

class CheckApproval implements ObserverInterface
{
	/**
     * @var Signature\Customers\Model\AdditionalFactory
     */
	protected $_additional;
	
	/**
     * @var Signature\Customers\Helper\Email
     */
	private $helperEmail;
	
	/**
     * @var Magento\Framework\Registry;
     */
	protected $coreRegistry;
	/**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $_request;
    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
	
	/**
     * CreatePost constructor.
     * @param Registry $registry
     * @param Email $helperEmail
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param AdditionalFactory $additional
     */
    public function __construct(
		Registry $registry,
		Email $helperEmail,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		AdditionalFactory $additional
		)
		{
		$this->coreRegistry = $registry;
		$this->_request = $request;
		$this->_storeManager = $storeManager;
		$this->helperEmail = $helperEmail;
		$this->_additional = $additional;
		}
	
	
	/**
     * @Check for approve account status
     *
     * @return call to email helper
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
	
		$event = $observer->getEvent();
		$customer = $event->getCustomer();
        
		$id = $customer->getId();
		$collection = $this->_additional->create()->getCollection()
							  ->addFieldToSelect(['customer_id','id','approve_status'])
							  ->addFieldToFilter('customer_id',$id);
		$data = $collection->getData();
		$post = $this->_request->getPostValue();
	    if($post['customer']['approve_account'] == 1){
			    $customerConfig = $this->_additional->create();
				if(!empty($data)){		
					$customerConfig->load($data[0]['id']);
				}
				$customerConfig->setCustomerId($id);
				$customerConfig->setApproveStatus(1);
				$customerConfig->save();
				if(!empty($data) && $data[0]['approve_status'] != 1){
				    return $this->helperEmail->sendEmail($customer);
				}
				elseif(empty($data)){
					return $this->helperEmail->sendEmail($customer);
				}
		}	
		
		
	}
}