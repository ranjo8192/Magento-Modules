<?php
namespace Signature\Customers\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Registry;

class CheckCustomer implements ObserverInterface
{
	/**
     *@var Magento\Framework\Registry
     */
    protected $coreRegistry;

	/**
     * Create constructor.
     * @param Registry $registry
     */
    public function __construct
	(
		Registry $registry
	)
    {
        $this->coreRegistry = $registry;
    }
	
	/**
     *
     * @return true
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $this->coreRegistry->register('is_new_account', true);
    }
}