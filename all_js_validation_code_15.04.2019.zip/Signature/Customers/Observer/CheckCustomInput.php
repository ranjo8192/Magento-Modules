<?php
namespace Signature\Customers\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Registry;
use Magento\Framework\App\RequestInterface;
use Signature\Customers\Helper\Email;
use Magento\Framework\Mail\Template\TransportBuilder;

class CheckCustomInput implements ObserverInterface
{
	
	private $helperEmail;
	
    protected $coreRegistry;
	/**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $_request;
    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
	
	
	/**
     * Create constructor.
     * @param Registry $registry
     * @param Email $helperEmail
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
		Registry $registry,
		Email $helperEmail,
		\Magento\Framework\App\Request\Http $request,
		\Magento\Store\Model\StoreManagerInterface $storeManager
		)
		{
		$this->coreRegistry = $registry;
		$this->_request = $request;
		$this->_storeManager = $storeManager;
		$this->helperEmail = $helperEmail;
		}

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		
		return $this->helperEmail->sendEmail($customer);
		
	}
}