<?php

namespace Signature\Customers\Plugin;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Registry;
use Magento\Framework\UrlInterface;

class Redirect
{
    const MODULE_ENABLED = 'customerlogin/general/enable';
	
	
	/**
     *@var Magento\Framework\Registry;
     */
    protected $coreRegistry;
	/**
     *@var Magento\Framework\UrlInterface;
     */
    protected $url;
	/**
     *@var Magento\Framework\Controller\ResultFactory;
     */
    protected $resultFactory;
	/**
     *@var Magento\Framework\Message\ManagerInterface;
     */
    protected $messageManager;
	/**
     *@var Magento\Customer\Model\Session;
     */
    protected $session;
	
	/**
     * Create constructor.
     * @param Registry $registry
     * @param UrlInterface $url,
     * @param ManagerInterface $messageManager
     * @param ScopeConfigInterface $scopeConfig
     * @param Session $customerSession
     * @param ResultFactory $resultFactory
     */
    public function __construct
	(
		Registry $registry,
		UrlInterface $url,
		ManagerInterface $messageManager,
		ScopeConfigInterface $scopeConfig,
		Session $customerSession,
		ResultFactory $resultFactory
    )
    {
        $this->session = $customerSession;
        $this->coreRegistry = $registry;
        $this->url = $url;
        $this->resultFactory = $resultFactory;
        $this->messageManager = $messageManager;
        $this->_scopeConfig = $scopeConfig;


    }
	
	/**
     * @plugin aroundGetRedurect
     *
     * @Redirect to custom page
     * @return $proceed();
     */
    public function aroundGetRedirect ($subject, \Closure $proceed)
    {

        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $enable = $this->_scopeConfig->getValue (self::MODULE_ENABLED, $storeScope);

        if ($enable && $this->coreRegistry->registry('is_new_account')) {

            // Clear previous messages
            $this->messageManager->getMessages(true);

            // Adding a custom message
            //$this->messageManager->addErrorMessage(__('Your account is not approved. Kindly contact website admin for assitance.'));

            $this->session->destroy();

            /** @var \Magento\Framework\Controller\Result\Redirect $result */
            $result = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

            $result->setUrl($this->url->getUrl('complete/index/success'));
            return $result;
        }

        return $proceed();
    }
}
