<?php
namespace Signature\Customers\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Escaper;
use Magento\Framework\Mail\Template\TransportBuilder;

class Email extends \Magento\Framework\App\Helper\AbstractHelper
{
	/**
     *@var Magento\Framework\Translate\Inline\StateInterface
     */
    protected $inlineTranslation;
	/**
     *@var Magento\Framework\Escaper
     */
    protected $escaper;
	/**
     *@var Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $transportBuilder;
	/**
     *@var Magento\Framework\App\Helper\Context
     */
    protected $logger;
	/**
     *@var \Magento\Store\Model\StoreManagerInterface
     */
	protected $_storeManager;
	
	/**
     * CreatePost constructor.
     * @param Context $context
     * @param StateInterface $inlineTranslation
     * @param Escaper $escaper
     * @param TransportBuilder $transportBuilder
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        StateInterface $inlineTranslation,
        Escaper $escaper,
        TransportBuilder $transportBuilder,
		\Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->inlineTranslation = $inlineTranslation;
        $this->escaper = $escaper;
        $this->transportBuilder = $transportBuilder;
        $this->logger = $context->getLogger();
		$this->_storeManager = $storeManager;
    }
	
	/**
     * @Send email after customer approval in the backend
     *
     * @return void
     */
    public function sendEmail($customer)
    {
		try {
            $this->inlineTranslation->suspend();
            $sender = [
                'name' => $this->escaper->escapeHtml('Admin'),
                'email' => $this->escaper->escapeHtml('ranjeets2@chetu.com'),
            ];
            $transport = $this->transportBuilder
                ->setTemplateIdentifier('account_approval_email_custom')
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_ADMINHTML,
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )
                ->setTemplateVars([
                    'store_name'  => $this->_storeManager->getStore()->getName(),
                    'name'  => $customer->getFirstName(),
                    'email'  => $customer->getEmail()
                ])
                ->setFrom($sender)
                ->addTo($customer->getEmail())
                ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();
        } catch (\Exception $e) {
            $this->logger->debug($e->getMessage());
        }
    }
}