<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See LICENSE.txt for license details.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Signature_Customers',
    __DIR__
);
