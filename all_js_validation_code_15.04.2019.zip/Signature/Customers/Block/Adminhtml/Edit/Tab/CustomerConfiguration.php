<?php
namespace Signature\Customers\Block\Adminhtml\Edit\Tab;
use Magento\Customer\Controller\RegistryConstants;
use Magento\Ui\Component\Layout\Tabs\TabInterface;
use Signature\Customers\Block\Collection;
use Signature\Customers\Model\AdditionalFactory;
use Magento\CatalogInventory\Model\Stock\StockItemRepository;
use Magento\Customer\Api\CustomerRepositoryInterface;
 
class CustomerConfiguration extends \Magento\Backend\Block\Template implements TabInterface
{
	/**
	 * @var \Magento\Customer\Api\CustomerRepositoryInterface
	 */
	protected $customerRepository;
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;
	
	/**
     * product Collection
     *
     * @var Signature\Customers\Block\Collection
     */
    protected $collection;
	
    /**
     * @var Signature\Customers\Model\Additional
     */
	 protected $_additional;
	 
	 /**
     * product StockItem
     *
     * @var Magento\CatalogInventory\Api\StockStateInterface
     */
	 protected $_stockItem;
     
	/**
     * CreatePost constructor.
     * @param Context $context
     * @param \Magento\Framework\Registry $registry
     * @param Collection $collection
     * @param AdditionalFactory $additional
     * @param StockItemRepository $stockItem
     * @param CustomerRepositoryInterface $customerRepository
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
		Collection $collection,
		AdditionalFactory $additional,
		StockItemRepository $stockItem,
		CustomerRepositoryInterface $customerRepository,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        $this->collection = $collection;
		$this->_additional = $additional;
		$this->_stockItem = $stockItem;
		$this->customerRepository = $customerRepository;
        parent::__construct($context, $data);
    }
 
    /**
     * @return string|null
     */
    public function getCustomerId()
    {
        return $this->_coreRegistry->registry(RegistryConstants::CURRENT_CUSTOMER_ID);
    }
    /**
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Doctor Configuration');
    }
    /**
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Doctor Configuration');
    }
    /**
     * @return bool
     */
    public function canShowTab()
    {
        if ($this->getCustomerId()) {
			//if($this->getGroupId() == 4){
               return true;
			//}
        }
        return false;
    }
 
    /**
     * @return bool
     */
    public function isHidden()
    {
        if ($this->getCustomerId()) {
            return false;
        }
        return true;
    }
    /**
     * Tab class getter
     *
     * @return string
     */
    public function getTabClass()
    {
        return '';
    }
    /**
     * Return URL link to Tab content
     *
     * @return string
     */
    public function getTabUrl()
    {
    //replace the tab with the url you want
        return $this->getUrl('customerconfig/*/CustomerConfiguration', ['_current' => true]);
    }
    /**
     * Tab should be loaded trough Ajax call
     *
     * @return bool
     */
    public function isAjaxLoaded()
    {
        return true;
    }
	
	/**
     * Get Product Collection
     *
     * @return Collection
     */
    public function getCollection()
    {
        return $this->collection->getProductCollection();
    }
	/**
     * Get Customet Config Collection
     *
     * @return Collection
     */
    public function getCustomerConfigCollection()
    {
		$customerId = $this->_coreRegistry->registry(RegistryConstants::CURRENT_CUSTOMER_ID);
		$ConfigCollection = $this->_additional->create()->getCollection()
														->addFieldToSelect('*')
														->addFieldToFilter('customer_id', array('eq' => $customerId));
        return $ConfigCollection;
    }
	
	/**
     * Get Product Stock Information
     *
     * @return Stco Information
     */
    public function getQty($id = null)
    {
        return $this->_stockItem->get($id)->getQty();
    }
	/**
     * Get Product Stock Information
     *
     * @return Customer group id
     */
	public function getGroupId()
	{
		if ($this->getCustomerId()) {
          $customer = $this->customerRepository->getById($this->getCustomerId());
		  return $customer->getGroupId();
        }
    }


}