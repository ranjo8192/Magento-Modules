<?php
namespace Signature\AdditionalContact\Model\ResourceModel;
class Additional extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
		//here "additional_contact" is table name and "additional_id" is the primary key of custom table
        $this->_init('additional_contact', 'additional_id');   
    }
}